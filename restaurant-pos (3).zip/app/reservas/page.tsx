"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus, CalendarIcon, Clock, Users, Phone, Check, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase"

// Tipos
type Mesa = {
  id: string
  numero: string
  capacidade: number
  status: string
}

type Reserva = {
  id: string
  cliente: string
  telefone: string
  data: Date
  hora: string
  pessoas: number
  mesa_id: string
  mesa_numero: string
  status: "confirmada" | "pendente" | "cancelada"
  observacoes?: string
}

export default function ReservasPage() {
  const [reservas, setReservas] = useState<Reserva[]>([])
  const [mesasDisponiveis, setMesasDisponiveis] = useState<Mesa[]>([])
  const [date, setDate] = useState<Date>(new Date())
  const [dialogOpen, setDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    cliente: "",
    telefone: "",
    data: new Date(),
    hora: "19:00",
    pessoas: 2,
    mesa_id: "",
    observacoes: "",
  })
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const supabase = getSupabaseClient()

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_reservas")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router, toast])

  // Carregar reservas e mesas disponíveis
  useEffect(() => {
    const fetchReservasEMesas = async () => {
      try {
        setLoading(true)

        // Buscar mesas disponíveis (apenas mesas livres)
        const { data: mesasData, error: mesasError } = await supabase
          .from("mesas")
          .select("*")
          .eq("status", "livre")
          .order("numero")

        if (mesasError) throw mesasError

        if (mesasData) {
          setMesasDisponiveis(mesasData)
        }

        // Verificar se a tabela de reservas existe
        const { error: checkError } = await supabase.from("reservas").select("id").limit(1)

        // Se a tabela não existir, vamos criá-la
        if (checkError && checkError.code === "42P01") {
          // Criar tabela de reservas
          const createTableSQL = `
            CREATE TABLE IF NOT EXISTS reservas (
              id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
              cliente VARCHAR(100) NOT NULL,
              telefone VARCHAR(20),
              data DATE NOT NULL,
              hora VARCHAR(5) NOT NULL,
              pessoas INTEGER NOT NULL,
              mesa_id UUID REFERENCES mesas(id) ON DELETE SET NULL,
              status VARCHAR(20) CHECK (status IN ('confirmada', 'pendente', 'cancelada')) DEFAULT 'pendente',
              observacoes TEXT,
              created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
              updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
            );
          `

          await supabase.rpc("execute_sql", { sql: createTableSQL })
          setReservas([])
        } else {
          // Buscar reservas
          const { data: reservasData, error: reservasError } = await supabase
            .from("reservas")
            .select(`
              id,
              cliente,
              telefone,
              data,
              hora,
              pessoas,
              mesa_id,
              status,
              observacoes,
              mesas:mesa_id (numero)
            `)
            .order("data", { ascending: false })

          if (reservasError) throw reservasError

          if (reservasData) {
            const formattedReservas = reservasData.map((reserva) => ({
              id: reserva.id,
              cliente: reserva.cliente,
              telefone: reserva.telefone,
              data: new Date(reserva.data),
              hora: reserva.hora,
              pessoas: reserva.pessoas,
              mesa_id: reserva.mesa_id,
              mesa_numero: reserva.mesas?.numero || "?",
              status: reserva.status as "confirmada" | "pendente" | "cancelada",
              observacoes: reserva.observacoes,
            }))

            setReservas(formattedReservas)
          }
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as reservas e mesas",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchReservasEMesas()

    // Configurar atualização em tempo real
    const channel = supabase
      .channel("reservas-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "reservas" }, () => {
        fetchReservasEMesas()
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "mesas" }, () => {
        fetchReservasEMesas()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, toast])

  // Filtrar reservas pela data selecionada
  const reservasDoDia = reservas.filter(
    (reserva) =>
      reserva.data.getDate() === date.getDate() &&
      reserva.data.getMonth() === date.getMonth() &&
      reserva.data.getFullYear() === date.getFullYear(),
  )

  // Atualizar campo do formulário
  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Adicionar nova reserva
  const handleAddReserva = async () => {
    try {
      setLoading(true)

      if (!formData.cliente.trim()) {
        toast({
          title: "Nome obrigatório",
          description: "Por favor, informe o nome do cliente",
          variant: "destructive",
        })
        return
      }

      if (!formData.mesa_id) {
        toast({
          title: "Mesa obrigatória",
          description: "Por favor, selecione uma mesa",
          variant: "destructive",
        })
        return
      }

      // Verificar se a tabela existe
      const { error: checkError } = await supabase.from("reservas").select("id").limit(1)

      // Se a tabela não existir, vamos criá-la
      if (checkError && checkError.code === "42P01") {
        // Criar tabela de reservas
        const createTableSQL = `
          CREATE TABLE IF NOT EXISTS reservas (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            cliente VARCHAR(100) NOT NULL,
            telefone VARCHAR(20),
            data DATE NOT NULL,
            hora VARCHAR(5) NOT NULL,
            pessoas INTEGER NOT NULL,
            mesa_id UUID REFERENCES mesas(id) ON DELETE SET NULL,
            status VARCHAR(20) CHECK (status IN ('confirmada', 'pendente', 'cancelada')) DEFAULT 'pendente',
            observacoes TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
          );
        `

        await supabase.rpc("execute_sql", { sql: createTableSQL })
      }

      // Inserir reserva
      const { data, error } = await supabase
        .from("reservas")
        .insert({
          cliente: formData.cliente,
          telefone: formData.telefone,
          data: formData.data.toISOString().split("T")[0],
          hora: formData.hora,
          pessoas: formData.pessoas,
          mesa_id: formData.mesa_id,
          status: "pendente",
          observacoes: formData.observacoes,
        })
        .select()

      if (error) throw error

      // Atualizar status da mesa para reservada
      const { error: mesaError } = await supabase
        .from("mesas")
        .update({ status: "reservada" })
        .eq("id", formData.mesa_id)

      if (mesaError) throw mesaError

      setDialogOpen(false)

      // Resetar formulário
      setFormData({
        cliente: "",
        telefone: "",
        data: new Date(),
        hora: "19:00",
        pessoas: 2,
        mesa_id: "",
        observacoes: "",
      })

      toast({
        title: "Reserva adicionada",
        description: `Reserva para ${formData.cliente} foi adicionada com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao adicionar reserva:", error)
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a reserva",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Atualizar status da reserva
  const handleUpdateStatus = async (id: string, status: "confirmada" | "pendente" | "cancelada") => {
    try {
      setLoading(true)

      const { error } = await supabase.from("reservas").update({ status }).eq("id", id)

      if (error) throw error

      // Se cancelada, liberar a mesa
      if (status === "cancelada") {
        const reserva = reservas.find((r) => r.id === id)
        if (reserva) {
          const { error: mesaError } = await supabase
            .from("mesas")
            .update({ status: "livre" })
            .eq("id", reserva.mesa_id)

          if (mesaError) throw mesaError
        }
      }

      toast({
        title: "Status atualizado",
        description: `Reserva ${status === "confirmada" ? "confirmada" : status === "cancelada" ? "cancelada" : "marcada como pendente"}.`,
      })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status da reserva",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Formatar data para exibição
  const formatarData = (data: Date) => {
    return data.toLocaleDateString("pt-BR", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    })
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciar Reservas</h1>
              <Button
                onClick={() => setDialogOpen(true)}
                className="bg-green-600 hover:bg-green-700"
                disabled={mesasDisponiveis.length === 0}
              >
                <Plus className="h-4 w-4 mr-2" />
                Nova Reserva
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-1 dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="dark:text-white">Calendário</CardTitle>
                  <CardDescription className="dark:text-gray-400">
                    Selecione uma data para ver as reservas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => date && setDate(date)}
                    className="rounded-md border dark:border-gray-700"
                  />

                  <div className="mt-4">
                    <h3 className="text-sm font-medium mb-2 dark:text-gray-300">Legenda</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-sm dark:text-gray-300">Confirmada</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                        <span className="text-sm dark:text-gray-300">Pendente</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                        <span className="text-sm dark:text-gray-300">Cancelada</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-md border border-yellow-200 dark:border-yellow-800">
                    <h3 className="text-sm font-medium mb-2 text-yellow-800 dark:text-yellow-300">Mesas Disponíveis</h3>
                    {mesasDisponiveis.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {mesasDisponiveis.map((mesa) => (
                          <span
                            key={mesa.id}
                            className="px-2 py-1 bg-white dark:bg-gray-800 rounded text-xs border border-gray-200 dark:border-gray-700"
                          >
                            Mesa {mesa.numero} ({mesa.capacidade} pessoas)
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-yellow-700 dark:text-yellow-400">
                        Não há mesas disponíveis para reserva no momento.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2 dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="dark:text-white">Reservas para {formatarData(date)}</CardTitle>
                  <CardDescription className="dark:text-gray-400">
                    {reservasDoDia.length} reservas encontradas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-12">
                      <div className="animate-spin h-8 w-8 border-4 border-green-500 border-t-transparent rounded-full mx-auto"></div>
                      <p className="mt-4 text-gray-500 dark:text-gray-400">Carregando reservas...</p>
                    </div>
                  ) : reservasDoDia.length > 0 ? (
                    <div className="space-y-4">
                      {reservasDoDia.map((reserva) => (
                        <div
                          key={reserva.id}
                          className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center gap-4 
                            ${
                              reserva.status === "confirmada"
                                ? "border-green-200 dark:border-green-900"
                                : reserva.status === "pendente"
                                  ? "border-yellow-200 dark:border-yellow-900"
                                  : "border-red-200 dark:border-red-900"
                            }`}
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium dark:text-white">{reserva.cliente}</h3>
                              <span
                                className={`text-xs px-2 py-1 rounded-full 
                                ${
                                  reserva.status === "confirmada"
                                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                    : reserva.status === "pendente"
                                      ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                                      : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                                }`}
                              >
                                {reserva.status === "confirmada"
                                  ? "Confirmada"
                                  : reserva.status === "pendente"
                                    ? "Pendente"
                                    : "Cancelada"}
                              </span>
                            </div>

                            <div className="grid grid-cols-2 gap-2 mt-2">
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <Clock className="h-4 w-4 mr-1" />
                                {reserva.hora}
                              </div>
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <Users className="h-4 w-4 mr-1" />
                                {reserva.pessoas} pessoas
                              </div>
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <Phone className="h-4 w-4 mr-1" />
                                {reserva.telefone}
                              </div>
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <CalendarIcon className="h-4 w-4 mr-1" />
                                Mesa {reserva.mesa_numero}
                              </div>
                            </div>

                            {reserva.observacoes && (
                              <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                                <p className="font-medium">Observações:</p>
                                <p>{reserva.observacoes}</p>
                              </div>
                            )}
                          </div>

                          <div className="flex gap-2 self-end sm:self-center">
                            {reserva.status !== "confirmada" && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-green-500 text-green-600 hover:bg-green-50 dark:border-green-700 dark:text-green-400 dark:hover:bg-green-900/20"
                                onClick={() => handleUpdateStatus(reserva.id, "confirmada")}
                                disabled={loading}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                Confirmar
                              </Button>
                            )}

                            {reserva.status !== "cancelada" && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-red-500 text-red-600 hover:bg-red-50 dark:border-red-700 dark:text-red-400 dark:hover:bg-red-900/20"
                                onClick={() => handleUpdateStatus(reserva.id, "cancelada")}
                                disabled={loading}
                              >
                                <X className="h-4 w-4 mr-1" />
                                Cancelar
                              </Button>
                            )}

                            {reserva.status === "cancelada" && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-yellow-500 text-yellow-600 hover:bg-yellow-50 dark:border-yellow-700 dark:text-yellow-400 dark:hover:bg-yellow-900/20"
                                onClick={() => handleUpdateStatus(reserva.id, "pendente")}
                                disabled={loading}
                              >
                                Restaurar
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <CalendarIcon className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600" />
                      <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma reserva encontrada</h3>
                      <p className="mt-1 text-gray-500 dark:text-gray-400">
                        Não há reservas para esta data. Adicione uma nova reserva.
                      </p>
                      <Button
                        onClick={() => setDialogOpen(true)}
                        className="mt-4 bg-green-600 hover:bg-green-700"
                        disabled={mesasDisponiveis.length === 0}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Nova Reserva
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>

      {/* Diálogo para adicionar nova reserva */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Nova Reserva</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Preencha os detalhes da reserva abaixo</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cliente" className="dark:text-gray-300">
                Nome do Cliente
              </Label>
              <Input
                id="cliente"
                value={formData.cliente}
                onChange={(e) => handleFormChange("cliente", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="telefone" className="dark:text-gray-300">
                Telefone
              </Label>
              <Input
                id="telefone"
                value={formData.telefone}
                onChange={(e) => handleFormChange("telefone", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="data" className="dark:text-gray-300">
                  Data
                </Label>
                <Input
                  id="data"
                  type="date"
                  value={formData.data.toISOString().split("T")[0]}
                  onChange={(e) => handleFormChange("data", new Date(e.target.value))}
                  className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="hora" className="dark:text-gray-300">
                  Hora
                </Label>
                <Input
                  id="hora"
                  type="time"
                  value={formData.hora}
                  onChange={(e) => handleFormChange("hora", e.target.value)}
                  className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="pessoas" className="dark:text-gray-300">
                  Número de Pessoas
                </Label>
                <Input
                  id="pessoas"
                  type="number"
                  min="1"
                  value={formData.pessoas}
                  onChange={(e) => handleFormChange("pessoas", Number.parseInt(e.target.value))}
                  className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="mesa" className="dark:text-gray-300">
                  Mesa
                </Label>
                <Select onValueChange={(value) => handleFormChange("mesa_id", value)}>
                  <SelectTrigger id="mesa" className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                    <SelectValue placeholder="Selecione uma mesa" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                    {mesasDisponiveis.map((mesa) => (
                      <SelectItem key={mesa.id} value={mesa.id}>
                        Mesa {mesa.numero} ({mesa.capacidade} pessoas)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="observacoes" className="dark:text-gray-300">
                Observações
              </Label>
              <Textarea
                id="observacoes"
                value={formData.observacoes}
                onChange={(e) => handleFormChange("observacoes", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                placeholder="Observações adicionais sobre a reserva"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleAddReserva} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Adicionando..." : "Adicionar Reserva"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
