"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { getSupabaseClient } from "@/lib/supabase"
import { Home, RefreshCw } from "lucide-react"
import Link from "next/link"

// Tipo para os pedidos
type Pedido = {
  id: string
  mesa_numero?: string
  cliente_nome?: string
  status: "pendente" | "preparando" | "pronto" | "entregue" | "cancelado"
  horario: string
  itens: PedidoItem[]
  observacoes?: string
  tempoEstimado?: number
}

type PedidoItem = {
  id: string
  nome: string
  quantidade: number
  observacao?: string
}

export default function CozinhaPage() {
  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [activeTab, setActiveTab] = useState("pendentes")
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_cozinha")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
      return
    }

    fetchPedidos()
  }, [isAuthenticated, checkPermission, router, toast])

  // Buscar pedidos
  const fetchPedidos = async () => {
    try {
      setLoading(true)
      const supabase = getSupabaseClient()

      // Buscar pedidos que não estão entregues ou cancelados
      const { data, error } = await supabase
        .from("pedidos")
        .select(`
    id,
    status,
    created_at
  `)
        .not("status", "in", '("entregue", "cancelado")')
        .order("created_at", { ascending: false })

      if (error) throw error

      if (data) {
        // Para cada pedido, buscar informações adicionais
        const pedidosCompletos = await Promise.all(
          data.map(async (pedido) => {
            // Buscar número da mesa
            let mesaNumero = "N/A"
            if (pedido.mesa_id) {
              const { data: mesaData } = await supabase.from("mesas").select("numero").eq("id", pedido.mesa_id).single()

              if (mesaData) {
                mesaNumero = mesaData.numero
              }
            }

            // Buscar itens do pedido
            const { data: itensData, error: itensError } = await supabase
              .from("pedido_itens")
              .select(`
                id,
                quantidade,
                observacao,
                produto_id,
                produtos (id, titulo)
              `)
              .eq("pedido_id", pedido.id)

            let itensFormatados: PedidoItem[] = []
            if (!itensError && itensData) {
              itensFormatados = itensData.map((item) => ({
                id: item.id,
                nome: item.produtos?.titulo || "Produto não encontrado",
                quantidade: item.quantidade,
                observacao: item.observacao,
              }))
            }

            // Formatar data
            const dataPedido = new Date(pedido.created_at)
            const horarioFormatado = dataPedido.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })

            // Retornar pedido formatado
            return {
              id: pedido.id,
              mesa_numero: "N/A", // Temporário até criar a estrutura do banco
              cliente_nome: "Cliente", // Temporário até criar a estrutura do banco
              status: pedido.status,
              horario: horarioFormatado,
              observacoes: undefined, // Remover até criar a coluna
              tempoEstimado: undefined, // Remover até criar a coluna
              itens: [], // Temporário até criar a estrutura do banco
            }
          }),
        )

        setPedidos(pedidosCompletos)
      }
    } catch (error) {
      console.error("Erro ao buscar pedidos:", error)
      toast({
        title: "Erro ao carregar pedidos",
        description: "Não foi possível carregar os pedidos do banco de dados.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Configurar subscription para atualizações em tempo real
  useEffect(() => {
    if (!isAuthenticated) return

    const supabase = getSupabaseClient()
    const subscription = supabase
      .channel("pedidos-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "pedidos",
        },
        (payload) => {
          console.log("Mudança nos pedidos:", payload)
          fetchPedidos()

          // Tocar som quando um novo pedido for criado
          if (payload.eventType === "INSERT" && payload.new.status === "pendente") {
            toast({
              title: "Novo pedido recebido!",
              description: "Um novo pedido foi adicionado à fila",
            })
          }
        },
      )
      .subscribe()

    // Limpar subscription ao desmontar
    return () => {
      subscription.unsubscribe()
    }
  }, [isAuthenticated, toast])

  // Filtrar pedidos por status
  const pedidosPendentes = pedidos.filter((p) => p.status === "pendente")
  const pedidosPreparando = pedidos.filter((p) => p.status === "preparando")
  const pedidosProntos = pedidos.filter((p) => p.status === "pronto")
  const pedidosEntregues = pedidos.filter((p) => p.status === "entregue")

  // Atualizar status do pedido
  const atualizarStatusPedido = async (pedidoId: string, novoStatus: Pedido["status"]) => {
    try {
      const supabase = getSupabaseClient()
      const { error } = await supabase.from("pedidos").update({ status: novoStatus }).eq("id", pedidoId)

      if (error) throw error

      // Atualizar estado local
      setPedidos((prev) => prev.map((pedido) => (pedido.id === pedidoId ? { ...pedido, status: novoStatus } : pedido)))

      toast({
        title: "Status atualizado",
        description: `Pedido marcado como ${novoStatus}`,
      })
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      toast({
        title: "Erro ao atualizar status",
        description: "Não foi possível atualizar o status do pedido.",
        variant: "destructive",
      })
    }
  }

  // Comentar temporariamente as funções que usam colunas inexistentes
  const definirTempoEstimado = async (pedidoId: string, tempoMinutos: number) => {
    // Função desabilitada até criar a estrutura do banco
  }

  // Renderizar card de pedido
  const renderPedidoCard = (pedido: Pedido) => {
    return (
      <Card key={pedido.id} className="mb-4 dark:bg-gray-800 dark:border-gray-700">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg dark:text-white">
                {pedido.mesa_numero ? `Mesa ${pedido.mesa_numero}` : "Pedido sem mesa"}
              </CardTitle>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {pedido.cliente_nome ? `Cliente: ${pedido.cliente_nome}` : "Cliente não informado"}
              </p>
            </div>
            <div className="flex flex-col items-end">
              <Badge
                className={`
                  ${pedido.status === "pendente" ? "bg-yellow-500" : ""}
                  ${pedido.status === "preparando" ? "bg-blue-500" : ""}
                  ${pedido.status === "pronto" ? "bg-green-500" : ""}
                  ${pedido.status === "entregue" ? "bg-gray-500" : ""}
                  ${pedido.status === "cancelado" ? "bg-red-500" : ""}
                `}
              >
                {pedido.status.charAt(0).toUpperCase() + pedido.status.slice(1)}
              </Badge>
              <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">{pedido.horario}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {pedido.itens.length > 0 ? (
              pedido.itens.map((item) => (
                <li key={item.id} className="flex justify-between dark:text-white">
                  <div>
                    <span className="font-medium">{item.quantidade}x</span> {item.nome}
                    {item.observacao && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 ml-5">{item.observacao}</p>
                    )}
                  </div>
                </li>
              ))
            ) : (
              <li className="text-gray-500 dark:text-gray-400">Nenhum item encontrado</li>
            )}
          </ul>

          {pedido.observacoes && (
            <div className="mt-4 p-2 bg-gray-100 dark:bg-gray-700 rounded-md">
              <p className="text-sm font-medium dark:text-gray-300">Observações:</p>
              <p className="text-sm dark:text-gray-300">{pedido.observacoes}</p>
            </div>
          )}

          {pedido.status === "pendente" && (
            <div className="mt-4 flex gap-2">
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => definirTempoEstimado(pedido.id, 10)}
              >
                10 min
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => definirTempoEstimado(pedido.id, 15)}
              >
                15 min
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => definirTempoEstimado(pedido.id, 20)}
              >
                20 min
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1"
                onClick={() => definirTempoEstimado(pedido.id, 30)}
              >
                30 min
              </Button>
            </div>
          )}

          {pedido.tempoEstimado && pedido.status !== "entregue" && (
            <div className="mt-2">
              <p className="text-sm dark:text-gray-300">
                Tempo estimado: <span className="font-medium">{pedido.tempoEstimado} minutos</span>
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="pt-0">
          {pedido.status === "pendente" && (
            <Button
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => atualizarStatusPedido(pedido.id, "preparando")}
            >
              Iniciar Preparo
            </Button>
          )}

          {pedido.status === "preparando" && (
            <Button
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => atualizarStatusPedido(pedido.id, "pronto")}
            >
              Marcar como Pronto
            </Button>
          )}

          {pedido.status === "pronto" && (
            <Button
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={() => atualizarStatusPedido(pedido.id, "entregue")}
            >
              Confirmar Entrega
            </Button>
          )}

          {pedido.status === "entregue" && (
            <p className="w-full text-center text-sm text-gray-500 dark:text-gray-400">Pedido finalizado</p>
          )}
        </CardFooter>
      </Card>
    )
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header>
          <Button variant="outline" size="sm" asChild className="ml-auto">
            <Link href="/">
              <Home className="h-4 w-4 mr-2" />
              Voltar ao Início
            </Link>
          </Button>
        </Header>
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Cozinha</h1>
              <div className="flex gap-2">
                <Button variant="outline" onClick={fetchPedidos} className="dark:border-gray-700 dark:text-gray-300">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Atualizar
                </Button>
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList className="dark:bg-gray-800">
                <TabsTrigger value="pendentes" className="dark:data-[state=active]:bg-gray-700">
                  Pendentes ({pedidosPendentes.length})
                </TabsTrigger>
                <TabsTrigger value="preparando" className="dark:data-[state=active]:bg-gray-700">
                  Preparando ({pedidosPreparando.length})
                </TabsTrigger>
                <TabsTrigger value="prontos" className="dark:data-[state=active]:bg-gray-700">
                  Prontos ({pedidosProntos.length})
                </TabsTrigger>
                <TabsTrigger value="entregues" className="dark:data-[state=active]:bg-gray-700">
                  Entregues ({pedidosEntregues.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pendentes">
                {loading ? (
                  <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                    <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                    <h3 className="text-xl font-medium dark:text-white mb-2">Carregando pedidos</h3>
                    <p className="text-gray-500 dark:text-gray-400">Aguarde enquanto buscamos as informações...</p>
                  </div>
                ) : pedidosPendentes.length === 0 ? (
                  <div className="text-center py-10 dark:text-gray-400">
                    <p>Não há pedidos pendentes no momento.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{pedidosPendentes.map(renderPedidoCard)}</div>
                )}
              </TabsContent>

              <TabsContent value="preparando">
                {pedidosPreparando.length === 0 ? (
                  <div className="text-center py-10 dark:text-gray-400">
                    <p>Não há pedidos em preparo no momento.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{pedidosPreparando.map(renderPedidoCard)}</div>
                )}
              </TabsContent>

              <TabsContent value="prontos">
                {pedidosProntos.length === 0 ? (
                  <div className="text-center py-10 dark:text-gray-400">
                    <p>Não há pedidos prontos para entrega no momento.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{pedidosProntos.map(renderPedidoCard)}</div>
                )}
              </TabsContent>

              <TabsContent value="entregues">
                {pedidosEntregues.length === 0 ? (
                  <div className="text-center py-10 dark:text-gray-400">
                    <p>Não há pedidos entregues recentemente.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{pedidosEntregues.map(renderPedidoCard)}</div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
