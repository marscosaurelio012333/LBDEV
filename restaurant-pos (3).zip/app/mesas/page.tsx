"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { MesaCard } from "@/components/mesa-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Search, Plus, Filter, RefreshCw, Table2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase"

export type StatusMesa = "livre" | "ocupada" | "reservada" | "em_atendimento" | "conta_solicitada"

// Update the Mesa type to include pedidos_items
export type Mesa = {
  id: string
  numero: string
  capacidade: number
  status: StatusMesa
  cliente?: string
  horarioAbertura?: string
  tempoOcupacao?: string
  valorTotal?: number
  pedidos?: number
  pedidos_items?: Array<{ id: string; nome: string; quantidade: number; preco: number }>
}

export default function MesasPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [mesas, setMesas] = useState<Mesa[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filtroStatus, setFiltroStatus] = useState<string>("todas")
  const [novaMesaDialogOpen, setNovaMesaDialogOpen] = useState(false)
  const [novaMesaForm, setNovaMesaForm] = useState({
    numero: "",
    capacidade: 4,
  })
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Função para buscar mesas
  const fetchMesas = async () => {
    try {
      setLoading(true)
      setError(null)
      console.log("Buscando mesas...")

      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("mesas").select("*")

      if (error) {
        console.error("Erro ao buscar mesas:", error)
        setError("Erro ao buscar mesas: " + error.message)
        return
      }

      console.log("Mesas encontradas:", data?.length || 0)
      // Convert database tables to our Mesa type
      const fetchedMesas: Mesa[] = data.map((table) => ({
        id: table.id,
        numero: table.numero,
        capacidade: table.capacidade,
        status: table.status as StatusMesa,
        cliente: table.cliente,
        horarioAbertura: table.horario_abertura
          ? new Date(table.horario_abertura).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          : undefined,
        tempoOcupacao: table.tempo_ocupacao,
        valorTotal: table.valor_total,
        pedidos: table.pedidos,
        pedidos_items: table.pedidos_items,
      }))
      setMesas(fetchedMesas)
    } catch (err) {
      console.error("Erro inesperado:", err)
      setError("Erro inesperado ao buscar mesas")
    } finally {
      setLoading(false)
    }
  }

  // Verificar autenticação e permissões
  useEffect(() => {
    console.log("Verificando autenticação e permissões...")
    console.log("isAuthenticated:", isAuthenticated)

    // Desabilitando temporariamente a verificação de permissão para debug
    /*
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_mesas")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
      return
    }
    */

    fetchMesas()
  }, [])

  // Filtrar mesas
  const mesasFiltradas = mesas.filter((mesa) => {
    // Filtro de pesquisa
    const matchesSearch =
      mesa.numero.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (mesa.cliente && mesa.cliente.toLowerCase().includes(searchTerm.toLowerCase()))

    // Filtro de status
    const matchesStatus = filtroStatus === "todas" || mesa.status === filtroStatus

    return matchesSearch && matchesStatus
  })

  // Agrupar mesas por status
  const mesasLivres = mesasFiltradas.filter((m) => m.status === "livre")
  const mesasOcupadas = mesasFiltradas.filter((m) => m.status === "ocupada")
  const mesasEmAtendimento = mesasFiltradas.filter((m) => m.status === "em_atendimento")
  const mesasContaSolicitada = mesasFiltradas.filter((m) => m.status === "conta_solicitada")
  const mesasReservadas = mesasFiltradas.filter((m) => m.status === "reservada")

  // Update the handleStatusChange function to accept order details
  const handleStatusChange = (
    mesaId: string,
    novoStatus: StatusMesa,
    cliente?: string,
    orderDetails?: {
      valorTotal?: number
      pedidos?: number
      pedidos_items?: Array<{ id: string; nome: string; quantidade: number; preco: number }>
    },
  ) => {
    setMesas((prev) =>
      prev.map((mesa) => {
        if (mesa.id === mesaId) {
          const updatedMesa: Mesa = { ...mesa, status: novoStatus }

          // Adicionar informações adicionais com base no novo status
          if (novoStatus === "ocupada" || novoStatus === "reservada") {
            updatedMesa.cliente = cliente
            updatedMesa.horarioAbertura = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
            updatedMesa.tempoOcupacao = "0 min"
          } else if (novoStatus === "livre") {
            // Limpar informações ao liberar a mesa
            delete updatedMesa.cliente
            delete updatedMesa.horarioAbertura
            delete updatedMesa.tempoOcupacao
            delete updatedMesa.pedidos
            delete updatedMesa.valorTotal
            delete updatedMesa.pedidos_items
          }

          // Add order details if provided
          if (orderDetails) {
            if (orderDetails.valorTotal !== undefined) updatedMesa.valorTotal = orderDetails.valorTotal
            if (orderDetails.pedidos !== undefined) updatedMesa.pedidos = orderDetails.pedidos
            if (orderDetails.pedidos_items !== undefined) updatedMesa.pedidos_items = orderDetails.pedidos_items
          }

          return updatedMesa
        }
        return mesa
      }),
    )
  }

  // Transferir mesa
  const handleTransferirMesa = (mesaOrigemId: string, mesaDestinoNumero: string) => {
    const mesaOrigem = mesas.find((m) => m.id === mesaOrigemId)
    const mesaDestino = mesas.find((m) => m.numero === mesaDestinoNumero)

    if (!mesaOrigem || !mesaDestino) {
      toast({
        title: "Erro na transferência",
        description: "Mesa de origem ou destino não encontrada",
        variant: "destructive",
      })
      return
    }

    if (mesaDestino.status !== "livre") {
      toast({
        title: "Mesa ocupada",
        description: "A mesa de destino precisa estar livre",
        variant: "destructive",
      })
      return
    }

    // Transferir dados da mesa de origem para a de destino
    setMesas((prev) =>
      prev.map((mesa) => {
        if (mesa.id === mesaDestino.id) {
          return {
            ...mesa,
            status: mesaOrigem.status,
            cliente: mesaOrigem.cliente,
            horarioAbertura: mesaOrigem.horarioAbertura,
            tempoOcupacao: mesaOrigem.tempoOcupacao,
            pedidos: mesaOrigem.pedidos,
            valorTotal: mesaOrigem.valorTotal,
            pedidos_items: mesaOrigem.pedidos_items,
          }
        } else if (mesa.id === mesaOrigem.id) {
          // Liberar a mesa de origem
          return {
            ...mesa,
            status: "livre",
            cliente: undefined,
            horarioAbertura: undefined,
            tempoOcupacao: undefined,
            pedidos: undefined,
            valorTotal: undefined,
            pedidos_items: undefined,
          }
        }
        return mesa
      }),
    )
  }

  // Abrir diálogo para criar nova mesa
  const handleNovaMesa = () => {
    setNovaMesaForm({
      numero: "",
      capacidade: 4,
    })
    setNovaMesaDialogOpen(true)
  }

  // Criar nova mesa
  const handleCriarMesa = async () => {
    // Validar número da mesa
    if (!novaMesaForm.numero.trim()) {
      toast({
        title: "Número de mesa obrigatório",
        description: "Por favor, informe o número da mesa",
        variant: "destructive",
      })
      return
    }

    // Verificar se já existe uma mesa com esse número
    const mesaExistente = mesas.some((m) => m.numero === novaMesaForm.numero)
    if (mesaExistente) {
      toast({
        title: "Mesa já existente",
        description: `Já existe uma mesa com o número ${novaMesaForm.numero}`,
        variant: "destructive",
      })
      return
    }

    try {
      const supabase = getSupabaseClient()

      // Insert new table into database
      const { data, error } = await supabase
        .from("mesas")
        .insert({
          numero: novaMesaForm.numero,
          capacidade: novaMesaForm.capacidade,
          status: "livre",
        })
        .select()

      if (error) throw error

      if (data && data.length > 0) {
        // Convert the returned data to our Mesa type
        const novaMesa: Mesa = {
          id: data[0].id,
          numero: data[0].numero,
          capacidade: data[0].capacidade,
          status: data[0].status as StatusMesa,
        }

        setMesas((prev) => [...prev, novaMesa])
        setNovaMesaDialogOpen(false)

        toast({
          title: "Mesa criada",
          description: `Mesa ${novaMesa.numero} foi criada com sucesso`,
        })
      }
    } catch (error) {
      console.error("Error creating table:", error)
      toast({
        title: "Erro ao criar mesa",
        description: "Não foi possível criar a mesa no banco de dados.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciamento de Mesas</h1>
              <div className="flex gap-2">
                <Button variant="outline" className="dark:border-gray-700 dark:text-gray-300" onClick={fetchMesas}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Atualizar
                </Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={handleNovaMesa}>
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Mesa
                </Button>
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Buscar mesa ou cliente..."
                  className="pl-10 dark:bg-gray-800 dark:border-gray-700"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger className="w-[180px] dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                    <SelectValue placeholder="Filtrar por status" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                    <SelectItem value="todas">Todas as mesas</SelectItem>
                    <SelectItem value="livre">Livres</SelectItem>
                    <SelectItem value="ocupada">Ocupadas</SelectItem>
                    <SelectItem value="em_atendimento">Em atendimento</SelectItem>
                    <SelectItem value="conta_solicitada">Conta solicitada</SelectItem>
                    <SelectItem value="reservada">Reservadas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {loading ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-medium dark:text-white mb-2">Carregando mesas</h3>
                <p className="text-gray-500 dark:text-gray-400">Aguarde enquanto buscamos as informações...</p>
              </div>
            ) : error ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <h3 className="text-xl font-medium text-red-500 mb-2">Erro ao carregar mesas</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">{error}</p>
                <Button onClick={fetchMesas}>Tentar novamente</Button>
              </div>
            ) : mesas.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <Table2 className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-medium dark:text-white mb-2">Nenhuma mesa cadastrada</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  Para começar a usar o sistema, adicione mesas ao seu restaurante.
                </p>
                <Button onClick={handleNovaMesa} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Primeira Mesa
                </Button>
              </div>
            ) : (
              <Tabs defaultValue="todas" className="space-y-4">
                <TabsList className="dark:bg-gray-800">
                  <TabsTrigger value="todas" className="dark:data-[state=active]:bg-gray-700">
                    Todas ({mesasFiltradas.length})
                  </TabsTrigger>
                  <TabsTrigger value="livres" className="dark:data-[state=active]:bg-gray-700">
                    Livres ({mesasLivres.length})
                  </TabsTrigger>
                  <TabsTrigger value="ocupadas" className="dark:data-[state=active]:bg-gray-700">
                    Ocupadas ({mesasOcupadas.length})
                  </TabsTrigger>
                  <TabsTrigger value="atendimento" className="dark:data-[state=active]:bg-gray-700">
                    Em Atendimento ({mesasEmAtendimento.length})
                  </TabsTrigger>
                  <TabsTrigger value="conta" className="dark:data-[state=active]:bg-gray-700">
                    Conta ({mesasContaSolicitada.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="todas">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {mesasFiltradas.map((mesa) => (
                      <MesaCard
                        key={mesa.id}
                        mesa={mesa}
                        onStatusChange={handleStatusChange}
                        onTransferirMesa={handleTransferirMesa}
                      />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="livres">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {mesasLivres.map((mesa) => (
                      <MesaCard
                        key={mesa.id}
                        mesa={mesa}
                        onStatusChange={handleStatusChange}
                        onTransferirMesa={handleTransferirMesa}
                      />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="ocupadas">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {mesasOcupadas.map((mesa) => (
                      <MesaCard
                        key={mesa.id}
                        mesa={mesa}
                        onStatusChange={handleStatusChange}
                        onTransferirMesa={handleTransferirMesa}
                      />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="atendimento">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {mesasEmAtendimento.map((mesa) => (
                      <MesaCard
                        key={mesa.id}
                        mesa={mesa}
                        onStatusChange={handleStatusChange}
                        onTransferirMesa={handleTransferirMesa}
                      />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="conta">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {mesasContaSolicitada.map((mesa) => (
                      <MesaCard
                        key={mesa.id}
                        mesa={mesa}
                        onStatusChange={handleStatusChange}
                        onTransferirMesa={handleTransferirMesa}
                      />
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </main>
      </div>

      {/* Diálogo para criar nova mesa */}
      <Dialog open={novaMesaDialogOpen} onOpenChange={setNovaMesaDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Adicionar Nova Mesa</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Preencha as informações para adicionar uma nova mesa ao sistema
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="numero" className="dark:text-gray-300">
                Número da Mesa*
              </Label>
              <Input
                id="numero"
                value={novaMesaForm.numero}
                onChange={(e) => setNovaMesaForm((prev) => ({ ...prev, numero: e.target.value }))}
                placeholder="Ex: 1, 2, A1, B2..."
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="capacidade" className="dark:text-gray-300">
                Capacidade (pessoas)*
              </Label>
              <Input
                id="capacidade"
                type="number"
                min="1"
                max="20"
                value={novaMesaForm.capacidade}
                onChange={(e) =>
                  setNovaMesaForm((prev) => ({ ...prev, capacidade: Number.parseInt(e.target.value) || 1 }))
                }
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setNovaMesaDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button onClick={handleCriarMesa} className="bg-green-600 hover:bg-green-700">
              Adicionar Mesa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
