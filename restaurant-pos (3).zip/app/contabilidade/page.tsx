"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts"
import {
  Download,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  Calendar,
  LineChart,
  Loader2,
  Filter,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { getSupabaseClient } from "@/lib/supabase"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// Cores para o gráfico vazio
const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

export default function ContabilidadePage() {
  const [periodoVendas, setPeriodoVendas] = useState("semana")
  const [periodoTransacoes, setPeriodoTransacoes] = useState("semana")
  const [vendasPorDia, setVendasPorDia] = useState<{ dia: string; vendas: number }[]>([])
  const [vendasPorCategoria, setVendasPorCategoria] = useState<{ nome: string; valor: number; porcentagem: number }[]>(
    [],
  )
  const [transacoes, setTransacoes] = useState<
    { id: string; data: string; descricao: string; tipo: "entrada" | "saida"; valor: number; categoria?: string }[]
  >([])

  // Add state for transactions and forms
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [vendaDialogOpen, setVendaDialogOpen] = useState(false)
  const [despesaDialogOpen, setDespesaDialogOpen] = useState(false)
  const [vendaForm, setVendaForm] = useState({
    descricao: "",
    valor: 0,
    data: new Date().toISOString().split("T")[0],
  })
  const [despesaForm, setDespesaForm] = useState({
    descricao: "",
    valor: 0,
    categoria: "aluguel",
    data: new Date().toISOString().split("T")[0],
  })
  
  // Adicionar filtros de data
  const [dataInicio, setDataInicio] = useState<Date>(new Date(new Date().setDate(new Date().getDate() - 30)))
  const [dataFim, setDataFim] = useState<Date>(new Date())
  const [filtroDialogOpen, setFiltroDialogOpen] = useState(false)
  
  const supabase = getSupabaseClient()

  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_contabilidade")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router, toast])

  // Função para carregar transações com base no período selecionado
  const loadTransactions = async (periodo: string = periodoTransacoes) => {
    try {
      setIsLoading(true)
      
      // Calcular datas com base no período
      let startDate = new Date()
      const endDate = new Date()
      
      if (periodo === "personalizado") {
        startDate = dataInicio
      } else if (periodo === "dia") {
        startDate.setHours(0, 0, 0, 0)
      } else if (periodo === "semana") {
        startDate.setDate(startDate.getDate() - 7)
      } else if (periodo === "mes") {
        startDate.setMonth(startDate.getMonth() - 1)
      } else if (periodo === "ano") {
        startDate.setFullYear(startDate.getFullYear() - 1)
      }
      
      // Formatar datas para o formato ISO
      const startDateStr = startDate.toISOString().split('T')[0]
      const endDateStr = endDate.toISOString().split('T')[0]
      
      // Buscar transações no período
      const { data, error } = await supabase
        .from("transacoes")
        .select("*")
        .gte("data", startDateStr)
        .lte("data", endDateStr)
        .order("data", { ascending: false })

      if (error) throw error

      if (data) {
        setTransacoes(
          data.map((t) => ({
            id: t.id,
            data: new Date(t.data).toLocaleDateString(),
            descricao: t.descricao,
            tipo: t.tipo,
            valor: t.valor,
            categoria: t.categoria
          })),
        )

        // Calculate totals
        const entradas = data.filter((t) => t.tipo === "entrada").reduce((acc, t) => acc + t.valor, 0)
        const saidas = data.filter((t) => t.tipo === "saida").reduce((acc, t) => acc + t.valor, 0)

        // Set vendasPorDia data
        const vendasAgrupadas = data
          .filter((t) => t.tipo === "entrada")
          .reduce(
            (acc, t) => {
              const dia = new Date(t.data).toLocaleDateString("pt-BR", { weekday: "long" })
              if (!acc[dia]) acc[dia] = 0
              acc[dia] += t.valor
              return acc
            },
            {} as Record<string, number>,
          )

        setVendasPorDia(Object.entries(vendasAgrupadas).map(([dia, vendas]) => ({ dia, vendas })))

        // Set vendasPorCategoria data
        const categoriasAgrupadas = data
          .filter((t) => t.tipo === "entrada" && t.categoria)
          .reduce(
            (acc, t) => {
              if (!acc[t.categoria]) acc[t.categoria] = 0
              acc[t.categoria] += t.valor
              return acc
            },
            {} as Record<string, number>,
          )

        const totalVendas = Object.values(categoriasAgrupadas).reduce((acc, val) => acc + val, 0)

        setVendasPorCategoria(
          Object.entries(categoriasAgrupadas).map(([nome, valor]) => ({
            nome,
            valor,
            porcentagem: Math.round((valor / totalVendas) * 100),
          })),
        )
      }
    } catch (error) {
      console.error("Error loading transactions:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar as transações",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Carregar transações ao montar o componente
  useEffect(() => {
    loadTransactions()
    
    // Configurar atualização em tempo real
    const channel = supabase
      .channel("transacoes-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "transacoes" }, () => {
        loadTransactions()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, toast])

  // Atualizar transações quando o período mudar
  useEffect(() => {
    loadTransactions(periodoTransacoes)
  }, [periodoTransacoes, dataInicio, dataFim])

  // Add function to handle form changes
  const handleVendaFormChange = (field: string, value: any) => {
    setVendaForm((prev) => ({ ...prev, [field]: value }))
  }

  const handleDespesaFormChange = (field: string, value: any) => {
    setDespesaForm((prev) => ({ ...prev, [field]: value }))
  }

  // Add function to register sale
  const handleRegistrarVenda = async () => {
    try {
      setIsSaving(true)

      if (!vendaForm.descricao) {
        toast({
          title: "Descrição obrigatória",
          description: "Por favor, informe a descrição da venda",
          variant: "destructive",
        })
        return
      }

      if (vendaForm.valor <= 0) {
        toast({
          title: "Valor inválido",
          description: "O valor deve ser maior que zero",
          variant: "destructive",
        })
        return
      }

      const { error } = await supabase.from("transacoes").insert({
        descricao: vendaForm.descricao,
        valor: vendaForm.valor,
        tipo: "entrada",
        categoria: "venda",
        data: vendaForm.data,
      })

      if (error) throw error

      // Reload transactions
      loadTransactions()

      setVendaDialogOpen(false)
      setVendaForm({
        descricao: "",
        valor: 0,
        data: new Date().toISOString().split("T")[0],
      })

      toast({
        title: "Venda registrada",
        description: `Venda de R$${vendaForm.valor.toFixed(2)} registrada com sucesso.`,
      })
    } catch (error) {
      console.error("Error registering sale:", error)
      toast({
        title: "Erro",
        description: "Não foi possível registrar a venda",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Add function to register expense
  const handleRegistrarDespesa = async () => {
    try {
      setIsSaving(true)

      if (!despesaForm.descricao) {
        toast({
          title: "Descrição obrigatória",
          description: "Por favor, informe a descrição da despesa",
          variant: "destructive",
        })
        return
      }

      if (despesaForm.valor <= 0) {
        toast({
          title: "Valor inválido",
          description: "O valor deve ser maior que zero",
          variant: "destructive",
        })
        return
      }

      const { error } = await supabase.from("transacoes").insert({
        descricao: despesaForm.descricao,
        valor: despesaForm.valor,
        tipo: "saida",
        categoria: despesaForm.categoria,
        data: despesaForm.data,
      })

      if (error) throw error

      // Reload transactions
      loadTransactions()

      setDespesaDialogOpen(false)
      setDespesaForm({
        descricao: "",
        valor: 0,
        categoria: "aluguel",
        data: new Date().toISOString().split("T")[0],
      })

      toast({
        title: "Despesa registrada",
        description: `Despesa de R$${despesaForm.valor.toFixed(2)} registrada com sucesso.`,
      })
    } catch (error) {
      console.error("Error registering expense:", error)
      toast({
        title: "Erro",
        description: "Não foi possível registrar a despesa",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Aplicar filtros personalizados
  const handleAplicarFiltros = () => {
    setPeriodoTransacoes("personalizado")
    setFiltroDialogOpen(false)
    loadTransactions("personalizado")
  }

  // Calcular totais
  const totalVendas = vendasPorDia.reduce((acc, item) => acc + item.vendas, 0)
  const totalEntradas = transacoes.filter((t) => t.tipo === "entrada").reduce((acc, t) => acc + t.valor, 0)
  const totalSaidas = transacoes.filter((t) => t.tipo === "saida").reduce((acc, t) => acc + t.valor, 0)
  const saldo = totalEntradas - totalSaidas

  // Dados vazios para gráficos
  const emptyBarData = [
    { dia: "Segunda", vendas: 0 },
    { dia: "Terça", vendas: 0 },
    { dia: "Quarta", vendas: 0 },
    { dia: "Quinta", vendas: 0 },
    { dia: "Sexta", vendas: 0 },
    { dia: "Sábado", vendas: 0 },
    { dia: "Domingo", vendas: 0 },
  ]

  const emptyPieData = [{ nome: "Sem dados", valor: 100, porcentagem: 100 }]

  return (
   <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Contabilidade</h1>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="dark:border-gray-700 dark:text-gray-300"
                  onClick={() => setFiltroDialogOpen(true)}
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
                <Button variant="outline" className="dark:border-gray-700 dark:text-gray-300">
                  <Download className="h-4 w-4 mr-2" />
                  Exportar Relatório
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Vendas Totais</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-2xl font-bold dark:text-white">R${totalVendas.toFixed(2)}</div>
                      <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                        <span>Nenhum dado comparativo</span>
                      </div>
                    </div>
                    <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                      <TrendingUp className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Despesas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-2xl font-bold dark:text-white">R${totalSaidas.toFixed(2)}</div>
                      <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                        <span>Nenhum dado comparativo</span>
                      </div>
                    </div>
                    <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                      <TrendingDown className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Saldo</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-2xl font-bold dark:text-white">R${saldo.toFixed(2)}</div>
                      <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                        <span>Nenhum dado comparativo</span>
                      </div>
                    </div>
                    <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                      <DollarSign className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Pedidos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-2xl font-bold dark:text-white">
                        {transacoes.filter(t => t.categoria === "venda").length}
                      </div>
                      <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                        <span>Nenhum dado comparativo</span>
                      </div>
                    </div>
                    <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
                      <ShoppingCart className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {isLoading ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <Loader2 className="h-16 w-16 mx-auto text-gray-400 mb-4 animate-spin" />
                <h3 className="text-xl font-medium dark:text-white mb-2">Carregando dados...</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  Aguarde enquanto os dados financeiros são carregados.
                </p>
              </div>
            ) : vendasPorDia.length === 0 && vendasPorCategoria.length === 0 && transacoes.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <LineChart className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-medium dark:text-white mb-2">Nenhum dado financeiro</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  Para começar a usar o sistema de contabilidade, adicione vendas e despesas.
                </p>
                <div className="flex justify-center gap-4">
                  <Button className="bg-green-600 hover:bg-green-700" onClick={() => setVendaDialogOpen(true)}>
                    Registrar Venda
                  </Button>
                  <Button className="bg-red-600 hover:bg-red-700" onClick={() => setDespesaDialogOpen(true)}>
                    Registrar Despesa
                  </Button>
                </div>
              </div>
            ) : (
              <Tabs defaultValue="vendas" className="space-y-4">
                <TabsList className="dark:bg-gray-800">
                  <TabsTrigger value="vendas" className="dark:data-[state=active]:bg-gray-700">
                    Vendas
                  </TabsTrigger>
                  <TabsTrigger value="transacoes" className="dark:data-[state=active]:bg-gray-700">
                    Transações
                  </TabsTrigger>
                  <TabsTrigger value="categorias" className="dark:data-[state=active]:bg-gray-700">
                    Categorias
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="vendas">
                  <Card className="dark:bg-gray-800 dark:border-gray-700">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <div>
                        <CardTitle className="dark:text-white">Vendas por Período</CardTitle>
                        <CardDescription className="dark:text-gray-400">Análise de vendas por período</CardDescription>
                      </div>
                      <Select value={periodoVendas} onValueChange={setPeriodoVendas}>
                        <SelectTrigger className="w-36 dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                          <SelectValue placeholder="Selecione o período" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="dia">Hoje</SelectItem>
                          <SelectItem value="semana">Esta Semana</SelectItem>
                          <SelectItem value="mes">Este Mês</SelectItem>
                          <SelectItem value="ano">Este Ano</SelectItem>
                          <SelectItem value="personalizado">Personalizado</SelectItem>
                        </SelectContent>
                      </Select>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={vendasPorDia.length > 0 ? vendasPorDia : emptyBarData}
                            margin={{
                              top: 20,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" className="stroke-gray-200 dark:stroke-gray-700" />
                            <XAxis dataKey="dia" className="fill-gray-500 dark:fill-gray-400" />
                            <YAxis
                              className="fill-gray-500 dark:fill-gray-400"
                              tickFormatter={(value) => `R$${value}`}
                            />
                            <Tooltip
                              formatter={(value) => [`R$${value}`, "Vendas"]}
                              contentStyle={{
                                backgroundColor: "rgba(255, 255, 255, 0.9)",
                                borderColor: "#e2e8f0",
                                color: "#1f2937",
                              }}
                            />
                            <Bar dataKey="vendas" fill="#22c55e" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      {vendasPorDia.length === 0 && (
                        <div className="text-center mt-4 text-gray-500 dark:text-gray-400">
                          Nenhum dado de vendas disponível para o período selecionado
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="transacoes">
                  <Card className="dark:bg-gray-800 dark:border-gray-700">
                    <CardHeader className="flex flex-row items-center justify-between">
                      <div>
                        <CardTitle className="dark:text-white">Transações Recentes</CardTitle>
                        <CardDescription className="dark:text-gray-400">Histórico de entradas e saídas</CardDescription>
                      </div>
                      <Select value={periodoTransacoes} onValueChange={setPeriodoTransacoes}>
                        <SelectTrigger className="w-36 dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                          <SelectValue placeholder="Selecione o período" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="dia">Hoje</SelectItem>
                          <SelectItem value="semana">Esta Semana</SelectItem>
                          <SelectItem value="mes">Este Mês</SelectItem>
                          <SelectItem value="ano">Este Ano</SelectItem>
                          <SelectItem value="personalizado">Personalizado</SelectItem>
                        </SelectContent>
                      </Select>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {periodoTransacoes === "personalizado" ? (
                            <span>
                              Período: {dataInicio.toLocaleDateString()} até {dataFim.toLocaleDateString()}
                            </span>
                          ) : (
                            <span>
                              Período: {periodoTransacoes === "dia" ? "Hoje" : periodoTransacoes === "semana" ? "Esta Semana" : periodoTransacoes === "mes" ? "Este Mês" : "Este Ano"}
                            </span>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="dark:border-gray-700 dark:text-gray-300"
                            onClick={() => setVendaDialogOpen(true)}
                          >
                            Registrar Entrada
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="dark:border-gray-700 dark:text-gray-300"
                            onClick={() => setDespesaDialogOpen(true)}
                          >
                            Registrar Saída
                          </Button>
                        </div>
                      </div>
                      
                      {transacoes.length > 0 ? (
                        <Table>
                          <TableHeader>
                            <TableRow className="dark:border-gray-700">
                              <TableHead className="dark:text-gray-300">Data</TableHead>
                              <TableHead className="dark:text-gray-300">Descrição</TableHead>
                              <TableHead className="dark:text-gray-300">Tipo</TableHead>
                              <TableHead className="dark:text-gray-300">Categoria</TableHead>
                              <TableHead className="text-right dark:text-gray-300">Valor</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {transacoes.map((transacao) => (
                              <TableRow key={transacao.id} className="dark:border-gray-700">
                                <TableCell className="dark:text-gray-300">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                                    {transacao.data}
                                  </div>
                                </TableCell>
                                <TableCell className="font-medium dark:text-white">{transacao.descricao}</TableCell>
                                <TableCell>
                                  <span
                                    className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                      transacao.tipo === "entrada"
                                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                        : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                                    }`}
                                  >
                                    {transacao.tipo === "entrada" ? "Entrada" : "Saída"}
                                  </span>
                                </TableCell>
                                <TableCell className="dark:text-gray-300">
                                  {transacao.categoria || "-"}
                                </TableCell>
                                <TableCell
                                  className={`text-right font-medium ${
                                    transacao.tipo === "entrada"
                                      ? "text-green-600 dark:text-green-400"
                                      : "text-red-600 dark:text-red-400"
                                  }`}
                                >
                                  {transacao.tipo === "entrada" ? "+" : "-"}R${transacao.valor.toFixed(2)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      ) : (
                        <div className="text-center py-12">
                          <Calendar className="h-12 w-12 mx-auto text-gray-300 dark:text-gray-600" />
                          <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma transação encontrada</h3>
                          <p className="mt-1 text-gray-500 dark:text-gray-400">
                            Não há transações registradas para o período selecionado
                          </p>
                          <div className="flex justify-center gap-4 mt-4">
                            <Button 
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => setVendaDialogOpen(true)}
                            >
                              Registrar Entrada
                            </Button>
                            <Button 
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => setDespesaDialogOpen(true)}
                            >
                              Registrar Saída
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="categorias">
                  <Card className="dark:bg-gray-800 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="dark:text-white">Vendas por Categoria</CardTitle>
                      <CardDescription className="dark:text-gray-400">
                        Distribuição de vendas por categoria de produto
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col lg:flex-row">
                      <div className="h-80 w-full lg:w-1/2">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={vendasPorCategoria.length > 0 ? vendasPorCategoria : emptyPieData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="valor"
                              nameKey="nome"
                              label={({ nome, porcentagem }) => `${nome}: ${porcentagem}%`}
                            >
                              {(vendasPorCategoria.length > 0 ? vendasPorCategoria : emptyPieData).map(
                                (entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ),
                              )}
                            </Pie>
                            <Legend />
                            <Tooltip
                              formatter={(value) => [`R$${value}`, "Valor"]}
                              contentStyle={{
                                backgroundColor: "rgba(255, 255, 255, 0.9)",
                                borderColor: "#e2e8f0",
                                color: "#1f2937",
                              }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="w-full lg:w-1/2 mt-6 lg:mt-0">
                        {vendasPorCategoria.length > 0 ? (
                          <Table>
                            <TableHeader>
                              <TableRow className="dark:border-gray-700">
                                <TableHead className="dark:text-gray-300">Categoria</TableHead>
                                <TableHead className="text-right dark:text-gray-300">Valor</TableHead>
                                <TableHead className="text-right dark:text-gray-300">%</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {vendasPorCategoria.map((categoria, index) => (
                                <TableRow key={index} className="dark:border-gray-700">
                                  <TableCell className="font-medium dark:text-white">
                                    <div className="flex items-center gap-2">
                                      <div
                                        className="w-3 h-3 rounded-full"
                                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                                      ></div>
                                      {categoria.nome}
                                    </div>
                                  </TableCell>
                                  <TableCell className="text-right dark:text-gray-300">
                                    R${categoria.valor.toLocaleString("pt-BR")}
                                  </TableCell>
                                  <TableCell className="text-right dark:text-gray-300">
                                    {categoria.porcentagem}%
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        ) : (
                          <div className="text-center mt-6 lg:mt-0 py-12 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <p className="text-gray-500 dark:text-gray-400">Nenhum dado de categorias disponível</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </main>
      </div>

      {/* Dialog for registering sales */}
      <Dialog open={vendaDialogOpen} onOpenChange={setVendaDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Registrar Venda</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Preencha os detalhes da venda abaixo</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="descricao-venda" className="dark:text-gray-300">
                Descrição
              </Label>
              <Input
                id="descricao-venda"
                value={vendaForm.descricao}
                onChange={(e) => handleVendaFormChange("descricao", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="valor-venda" className="dark:text-gray-300">
                Valor (R$)
              </Label>
              <Input
                id="valor-venda"
                type="number"
                step="0.01"
                value={vendaForm.valor}
                onChange={(e) => handleVendaFormChange("valor", Number(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="data-venda" className="dark:text-gray-300">
                Data
              </Label>
              <Input
                id="data-venda"
                type="date"
                value={vendaForm.data}
                onChange={(e) => handleVendaFormChange("data", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setVendaDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={isSaving}
            >
              Cancelar
            </Button>
            <Button onClick={handleRegistrarVenda} className="bg-green-600 hover:bg-green-700" disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Registrando...
                </>
              ) : (
                "Registrar Venda"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog for registering expenses */}
      <Dialog open={despesaDialogOpen} onOpenChange={setDespesaDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Registrar Despesa</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Preencha os detalhes da despesa abaixo</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="descricao-despesa" className="dark:text-gray-300">
                Descrição
              </Label>
              <Input
                id="descricao-despesa"
                value={despesaForm.descricao}
                onChange={(e) => handleDespesaFormChange("descricao", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="valor-despesa" className="dark:text-gray-300">
                Valor (R$)
              </Label>
              <Input
                id="valor-despesa"
                type="number"
                step="0.01"
                value={despesaForm.valor}
                onChange={(e) => handleDespesaFormChange("valor", Number(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="categoria-despesa" className="dark:text-gray-300">
                Categoria
              </Label>
              <Select
                value={despesaForm.categoria}
                onValueChange={(value) => handleDespesaFormChange("categoria", value)}
              >
                <SelectTrigger className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                  <SelectItem value="aluguel">Aluguel</SelectItem>
                  <SelectItem value="funcionarios">Funcionários</SelectItem>
                  <SelectItem value="insumos">Insumos</SelectItem>
                  <SelectItem value="equipamentos">Equipamentos</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="impostos">Impostos</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="data-despesa" className="dark:text-gray-300">
                Data
              </Label>
              <Input
                id="data-despesa"
                type="date"
                value={despesaForm.data}
                onChange={(e) => handleDespesaFormChange("data", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDespesaDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={isSaving}
            >
              Cancelar
            </Button>
            <Button onClick={handleRegistrarDespesa} className="bg-red-600 hover:bg-red-700" disabled={isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Registrando...
                </>
              ) : (
                "Registrar Despesa"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog for custom filters */}
      <Dialog open={filtroDialogOpen} onOpenChange={setFiltroDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Filtros Personalizados</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Defina o período para filtrar os dados
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="data-inicio" className="dark:text-gray-300">
                Data Inicial
              </Label>
              <Input
                id="data-inicio"
                type="date"
                value={dataInicio.toISOString().split("T")[0]}
                onChange={(e) => setDataInicio(new Date(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="data-fim" className="dark:text-gray-300">
                Data Final
              </Label>
              <Input
                id="data-fim"
                type="date"
                value={dataFim.toISOString().split("T")[0]}
                onChange={(e) => setDataFim(new Date(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>
            <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setFiltroDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleAplicarFiltros}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Aplicar Filtros
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
