"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Truck, MapPin, Phone, Clock, CheckCircle2, XCircle, AlertCircle, User } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase"

// Tipos
type StatusEntrega = "pendente" | "em_rota" | "entregue" | "cancelada"

type Entrega = {
  id: string
  cliente: string
  telefone: string
  endereco: string
  pedido: string
  valor: number
  status: StatusEntrega
  horario: string
  entregador?: string
  tempoEstimado?: string
}

export default function EntregasPage() {
  const [entregas, setEntregas] = useState<Entrega[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [statusDialogOpen, setStatusDialogOpen] = useState(false)
  const [currentEntrega, setCurrentEntrega] = useState<Entrega | null>(null)
  const [formData, setFormData] = useState<Omit<Entrega, "id" | "status" | "horario">>({
    cliente: "",
    telefone: "",
    endereco: "",
    pedido: "",
    valor: 0,
    entregador: "",
  })
  const [novoStatus, setNovoStatus] = useState<StatusEntrega>("pendente")
  const { toast } = useToast()
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const supabase = getSupabaseClient()
  const [loading, setLoading] = useState(false)

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_entregas")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router, toast])

  // Carregar entregas do banco de dados
  useEffect(() => {
    async function loadEntregas() {
      try {
        setLoading(true)
        const { data, error } = await supabase.from("entregas").select("*").order("created_at", { ascending: false })

        if (error) {
          console.error("Error fetching deliveries:", error)
          // Usar dados mockados se houver erro
          setEntregas([])
          return
        }

        if (data) {
          const formattedEntregas = data.map((entrega) => ({
            id: entrega.id,
            cliente: entrega.cliente,
            telefone: entrega.telefone || "",
            endereco: entrega.endereco,
            pedido: entrega.pedido_id || "Pedido manual",
            valor: entrega.valor_entrega || 0,
            status: entrega.status as StatusEntrega,
            horario: new Date(entrega.created_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
            entregador: entrega.entregador,
            tempoEstimado: "20 min",
          }))
          setEntregas(formattedEntregas)
        }
      } catch (error) {
        console.error("Error loading deliveries:", error)
      } finally {
        setLoading(false)
      }
    }

    loadEntregas()

    // Configurar atualização em tempo real
    const channel = supabase
      .channel("entregas-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "entregas" }, () => {
        loadEntregas()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase, toast])

  // Filtrar entregas com base no termo de pesquisa
  const entregasFiltradas = entregas.filter(
    (entrega) =>
      entrega.cliente.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entrega.endereco.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (entrega.entregador && entrega.entregador.toLowerCase().includes(searchTerm.toLowerCase())) ||
      entrega.pedido.toString().includes(searchTerm.toLowerCase()),
  )

  // Agrupar entregas por status
  const entregasPendentes = entregasFiltradas.filter((e) => e.status === "pendente")
  const entregasEmRota = entregasFiltradas.filter((e) => e.status === "em_rota")
  const entregasEntregues = entregasFiltradas.filter((e) => e.status === "entregue")
  const entregasCanceladas = entregasFiltradas.filter((e) => e.status === "cancelada")

  // Atualizar campo do formulário
  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Adicionar nova entrega
  const handleAddEntrega = async () => {
    try {
      setLoading(true)

      if (!formData.cliente) {
        toast({
          title: "Cliente obrigatório",
          description: "Por favor, informe o nome do cliente",
          variant: "destructive",
        })
        return
      }

      if (!formData.endereco) {
        toast({
          title: "Endereço obrigatório",
          description: "Por favor, informe o endereço de entrega",
          variant: "destructive",
        })
        return
      }

      if (!formData.entregador) {
        toast({
          title: "Entregador obrigatório",
          description: "Por favor, informe o nome do entregador",
          variant: "destructive",
        })
        return
      }

      // Dados a serem inseridos
      const entregaData = {
        cliente: formData.cliente,
        telefone: formData.telefone || "",
        endereco: formData.endereco,
        valor_entrega: formData.valor || 0,
        entregador: formData.entregador,
        status: "pendente",
      }

      console.log("Tentando inserir entrega:", entregaData)

      // Inserir entrega no banco de dados
      const { data, error } = await supabase.from("entregas").insert(entregaData).select()

      if (error) {
        console.error("Erro detalhado ao adicionar entrega:", error)
        throw error
      }

      // Adicionar entrega à lista local
      if (data && data.length > 0) {
        const novaEntrega: Entrega = {
          id: data[0].id,
          cliente: formData.cliente,
          telefone: formData.telefone || "",
          endereco: formData.endereco,
          pedido: "Pedido manual",
          valor: formData.valor || 0,
          status: "pendente",
          horario: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
          entregador: formData.entregador,
        }

        setEntregas((prev) => [novaEntrega, ...prev])
      }

      setDialogOpen(false)

      // Resetar formulário
      setFormData({
        cliente: "",
        telefone: "",
        endereco: "",
        pedido: "",
        valor: 0,
        entregador: "",
      })

      toast({
        title: "Entrega adicionada",
        description: `Entrega para ${formData.cliente} foi adicionada com sucesso.`,
      })
    } catch (error) {
      console.error("Erro ao adicionar entrega:", error)
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a entrega. Verifique o console para mais detalhes.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Abrir diálogo para atualizar status
  const handleOpenStatusDialog = (entrega: Entrega) => {
    setCurrentEntrega(entrega)
    setNovoStatus(entrega.status)
    setStatusDialogOpen(true)
  }

  // Atualizar status da entrega
  const handleUpdateStatus = async () => {
    if (!currentEntrega) return

    try {
      setLoading(true)

      // Atualizar status no banco de dados
      const { error } = await supabase
        .from("entregas")
        .update({
          status: novoStatus,
          horario_saida: novoStatus === "em_rota" ? new Date().toISOString() : undefined,
          horario_entrega: novoStatus === "entregue" ? new Date().toISOString() : undefined,
        })
        .eq("id", currentEntrega.id)

      if (error) throw error

      // Atualizar entrega na lista local
      setEntregas((prev) =>
        prev.map((entrega) => (entrega.id === currentEntrega.id ? { ...entrega, status: novoStatus } : entrega)),
      )

      setStatusDialogOpen(false)

      toast({
        title: "Status atualizado",
        description: `Status da entrega atualizado para ${
          novoStatus === "pendente"
            ? "Pendente"
            : novoStatus === "em_rota"
              ? "Em Rota"
              : novoStatus === "entregue"
                ? "Entregue"
                : "Cancelada"
        }.`,
      })
    } catch (error) {
      console.error("Error updating delivery status:", error)
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o status da entrega",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Renderizar card de entrega
  const renderEntregaCard = (entrega: Entrega) => (
    <Card key={entrega.id} className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="dark:text-white">{entrega.cliente}</CardTitle>
            <CardDescription className="dark:text-gray-400">
              Pedido #{entrega.id.substring(0, 8)} • {entrega.horario}
            </CardDescription>
          </div>
          <div
            className={`px-2 py-1 rounded-full text-xs font-medium 
            ${
              entrega.status === "pendente"
                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                : entrega.status === "em_rota"
                  ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                  : entrega.status === "entregue"
                    ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                    : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
            }`}
          >
            {entrega.status === "pendente"
              ? "Pendente"
              : entrega.status === "em_rota"
                ? "Em Rota"
                : entrega.status === "entregue"
                  ? "Entregue"
                  : "Cancelada"}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 text-gray-500 dark:text-gray-400 mt-0.5" />
            <span className="text-sm dark:text-gray-300">{entrega.endereco}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-gray-500 dark:text-gray-400" />
            <span className="text-sm dark:text-gray-300">{entrega.telefone}</span>
          </div>
          {entrega.entregador && (
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-gray-500 dark:text-gray-400" />
              <span className="text-sm dark:text-gray-300">Entregador: {entrega.entregador}</span>
            </div>
          )}
          <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-md">
            <p className="text-sm font-medium mb-1 dark:text-gray-300">Itens do Pedido:</p>
            <p className="text-sm dark:text-gray-400">{entrega.pedido}</p>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm font-medium dark:text-gray-300">Total:</span>
              <span className="font-bold text-green-600 dark:text-green-400">R${entrega.valor.toFixed(2)}</span>
            </div>
          </div>

          {entrega.status === "em_rota" && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-blue-500" />
                <span className="text-sm dark:text-gray-300">{entrega.entregador}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                <span className="text-sm dark:text-gray-300">{entrega.tempoEstimado}</span>
              </div>
            </div>
          )}

          <Button onClick={() => handleOpenStatusDialog(entrega)} className="w-full bg-green-600 hover:bg-green-700">
            Atualizar Status
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciar Entregas</h1>
              <Button onClick={() => setDialogOpen(true)} className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Nova Entrega
              </Button>
            </div>

            <div className="mb-6 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Pesquisar entregas..."
                className="pl-10 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {entregas.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <Truck className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-medium dark:text-white mb-2">Nenhuma entrega cadastrada</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  Para começar a usar o sistema de entregas, adicione sua primeira entrega.
                </p>
                <Button onClick={() => setDialogOpen(true)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Primeira Entrega
                </Button>
              </div>
            ) : (
              <Tabs defaultValue="pendentes" className="space-y-4">
                <TabsList className="dark:bg-gray-800">
                  <TabsTrigger value="pendentes" className="dark:data-[state=active]:bg-gray-700">
                    Pendentes ({entregasPendentes.length})
                  </TabsTrigger>
                  <TabsTrigger value="em_rota" className="dark:data-[state=active]:bg-gray-700">
                    Em Rota ({entregasEmRota.length})
                  </TabsTrigger>
                  <TabsTrigger value="entregues" className="dark:data-[state=active]:bg-gray-700">
                    Entregues ({entregasEntregues.length})
                  </TabsTrigger>
                  <TabsTrigger value="canceladas" className="dark:data-[state=active]:bg-gray-700">
                    Canceladas ({entregasCanceladas.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="pendentes">
                  {entregasPendentes.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {entregasPendentes.map(renderEntregaCard)}
                    </div>
                  ) : (
                    <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
                      <AlertCircle className="h-12 w-12 mx-auto text-yellow-500" />
                      <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma entrega pendente</h3>
                      <p className="mt-1 text-gray-500 dark:text-gray-400">Não há entregas pendentes no momento.</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="em_rota">
                  {entregasEmRota.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {entregasEmRota.map(renderEntregaCard)}
                    </div>
                  ) : (
                    <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
                      <Truck className="h-12 w-12 mx-auto text-blue-500" />
                      <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma entrega em rota</h3>
                      <p className="mt-1 text-gray-500 dark:text-gray-400">Não há entregas em andamento no momento.</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="entregues">
                  {entregasEntregues.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {entregasEntregues.map(renderEntregaCard)}
                    </div>
                  ) : (
                    <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
                      <CheckCircle2 className="h-12 w-12 mx-auto text-green-500" />
                      <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma entrega concluída</h3>
                      <p className="mt-1 text-gray-500 dark:text-gray-400">Não há entregas concluídas no momento.</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="canceladas">
                  {entregasCanceladas.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {entregasCanceladas.map(renderEntregaCard)}
                    </div>
                  ) : (
                    <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg">
                      <XCircle className="h-12 w-12 mx-auto text-red-500" />
                      <h3 className="mt-4 text-lg font-medium dark:text-white">Nenhuma entrega cancelada</h3>
                      <p className="mt-1 text-gray-500 dark:text-gray-400">Não há entregas canceladas no momento.</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            )}
          </div>
        </main>
      </div>

      {/* Diálogo para adicionar nova entrega */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Nova Entrega</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Preencha os detalhes da entrega abaixo</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cliente" className="dark:text-gray-300">
                Nome do Cliente
              </Label>
              <Input
                id="cliente"
                value={formData.cliente}
                onChange={(e) => handleFormChange("cliente", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="telefone" className="dark:text-gray-300">
                Telefone
              </Label>
              <Input
                id="telefone"
                value={formData.telefone}
                onChange={(e) => handleFormChange("telefone", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="endereco" className="dark:text-gray-300">
                Endereço Completo
              </Label>
              <Input
                id="endereco"
                value={formData.endereco}
                onChange={(e) => handleFormChange("endereco", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="entregador" className="dark:text-gray-300">
                Nome do Entregador
              </Label>
              <Input
                id="entregador"
                value={formData.entregador}
                onChange={(e) => handleFormChange("entregador", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="pedido" className="dark:text-gray-300">
                Itens do Pedido
              </Label>
              <Input
                id="pedido"
                value={formData.pedido}
                onChange={(e) => handleFormChange("pedido", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="valor" className="dark:text-gray-300">
                Valor Total (R$)
              </Label>
              <Input
                id="valor"
                type="number"
                step="0.01"
                value={formData.valor}
                onChange={(e) => handleFormChange("valor", Number.parseFloat(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleAddEntrega} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Adicionando..." : "Adicionar Entrega"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para atualizar status */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Atualizar Status da Entrega</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Selecione o novo status para esta entrega
            </DialogDescription>
          </DialogHeader>

          {currentEntrega && (
            <div className="py-4">
              <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="font-medium dark:text-white">{currentEntrega.cliente}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{currentEntrega.endereco}</p>
                <div className="mt-2 flex justify-between">
                  <span className="text-sm dark:text-gray-300">Pedido #{currentEntrega.id.substring(0, 8)}</span>
                  <span className="font-medium text-green-600 dark:text-green-400">
                    R${currentEntrega.valor.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="status" className="dark:text-gray-300">
                    Status da Entrega
                  </Label>
                  <Select value={novoStatus} onValueChange={(value: StatusEntrega) => setNovoStatus(value)}>
                    <SelectTrigger className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                      <SelectItem value="pendente">Pendente</SelectItem>
                      <SelectItem value="em_rota">Em Rota</SelectItem>
                      <SelectItem value="entregue">Entregue</SelectItem>
                      <SelectItem value="cancelada">Cancelada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setStatusDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleUpdateStatus} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Atualizando..." : "Atualizar Status"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
