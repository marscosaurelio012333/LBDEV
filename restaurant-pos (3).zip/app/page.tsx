"use client"

import { useEffect, useState } from "react"
import { CategoryFilter } from "@/components/category-filter"
import { FoodGrid } from "@/components/food-grid"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Cart } from "@/components/cart"
import { DiningMode } from "@/components/dining-mode"
import { AppProvider } from "@/contexts/app-context"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

export default function Home() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login")
    }
  }, [user, loading, router])

  if (loading || !user) {
    return null
  }

  return (
    <AppProvider>
      <div className="flex flex-col min-h-screen">
        <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
        <main className="flex-1 container mx-auto px-4 pb-20">
          {/* Mover o DiningMode para cima dos itens do cardápio */}
          <div className="mb-6 mt-4">
            <DiningMode />
          </div>
          <CategoryFilter />
          <FoodGrid searchQuery={searchQuery} />
        </main>
        <Footer />
        <Cart />
      </div>
    </AppProvider>
  )
}
