"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Plus, Pencil, Trash2, Search, Upload, Loader2, ImageIcon } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase"
import type { FoodItem } from "@/lib/types"

// Tipo para categoria
type Categoria = {
  id: string
  nome: string
  icone: string
  ordem: number
  ativa: boolean
}

export default function GerenciarProdutos() {
  const [produtos, setProdutos] = useState<FoodItem[]>([])
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentProduto, setCurrentProduto] = useState<FoodItem | null>(null)
  const [formData, setFormData] = useState({
    id: "",
    titulo: "",
    descricao: "",
    preco: 0,
    desconto: 0,
    tipo: "Vegetariano",
    categoria_id: "",
    imagem: "",
    destaque: false,
    disponivel: true,
  })
  const [loading, setLoading] = useState(false)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const { toast } = useToast()
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const supabase = getSupabaseClient()

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_admin")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router, toast])

  // Carregar produtos e categorias
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Buscar categorias
        const { data: categoriasData, error: categoriasError } = await supabase
          .from("categorias")
          .select("*")
          .eq("ativa", true)
          .order("ordem")

        if (categoriasError) throw categoriasError

        if (categoriasData) {
          setCategorias(categoriasData)
        }

        // Buscar produtos
        const { data: produtosData, error: produtosError } = await supabase.from("produtos").select("*").order("titulo")

        if (produtosError) throw produtosError

        if (produtosData) {
          // Converter dados do banco para o formato FoodItem
          const formattedProdutos: FoodItem[] = produtosData.map((item) => ({
            id: item.id,
            image: item.imagem_url || "/placeholder.svg?height=200&width=200",
            titulo: item.titulo,
            descricao: item.descricao || "",
            preco: item.preco,
            desconto: item.desconto || 0,
            tipo: item.tipo as "Vegetariano" | "Não Vegetariano",
            categoria: item.categoria_id,
            quantidade: 0,
            destaque: item.destaque || false,
            disponivel: item.disponivel !== false,
          }))
          setProdutos(formattedProdutos)
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar os dados",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [supabase, toast])

  // Obter categoria pelo ID
  const getCategoriaById = (id: string): Categoria | undefined => {
    return categorias.find((cat) => cat.id === id)
  }

  // Filtrar produtos com base no termo de pesquisa
  const produtosFiltrados = produtos.filter(
    (produto) =>
      produto.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (produto.descricao && produto.descricao.toLowerCase().includes(searchTerm.toLowerCase())) ||
      produto.tipo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getCategoriaById(produto.categoria)?.nome.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Abrir diálogo para adicionar novo produto
  const handleAddNew = () => {
    setCurrentProduto(null)
    setFormData({
      id: "",
      titulo: "",
      descricao: "",
      preco: 0,
      desconto: 0,
      tipo: "Vegetariano",
      categoria_id: categorias.length > 0 ? categorias[0].id : "",
      imagem: "",
      destaque: false,
      disponivel: true,
    })
    setImagePreview(null)
    setDialogOpen(true)
  }

  // Abrir diálogo para editar produto existente
  const handleEdit = (produto: FoodItem) => {
    setCurrentProduto(produto)
    setFormData({
      id: produto.id,
      titulo: produto.titulo,
      descricao: produto.descricao || "",
      preco: produto.preco,
      desconto: produto.desconto || 0,
      tipo: produto.tipo,
      categoria_id: produto.categoria,
      imagem: produto.image,
      destaque: produto.destaque || false,
      disponivel: produto.disponivel !== false,
    })
    setImagePreview(produto.image)
    setDialogOpen(true)
  }

  // Abrir diálogo para confirmar exclusão
  const handleDeleteConfirm = (produto: FoodItem) => {
    setCurrentProduto(produto)
    setDeleteDialogOpen(true)
  }

  // Excluir produto
  const handleDelete = async () => {
    if (!currentProduto) return

    try {
      setLoading(true)

      // Primeiro, verificar se o produto está sendo usado em algum pedido
      const { data: pedidoItens, error: checkError } = await supabase
        .from("pedido_itens")
        .select("id")
        .eq("produto_id", currentProduto.id)
        .limit(1)

      if (checkError) throw checkError

      // Se o produto estiver sendo usado em pedidos, não permitir a exclusão
      if (pedidoItens && pedidoItens.length > 0) {
        toast({
          title: "Não é possível excluir",
          description:
            "Este produto está associado a pedidos existentes. Em vez disso, você pode marcá-lo como indisponível.",
          variant: "destructive",
        })
        setDeleteDialogOpen(false)
        return
      }

      // Se não estiver sendo usado, prosseguir com a exclusão
      const { error } = await supabase.from("produtos").delete().eq("id", currentProduto.id)

      if (error) throw error

      setProdutos((prev) => prev.filter((p) => p.id !== currentProduto.id))
      toast({
        title: "Produto excluído",
        description: `${currentProduto.titulo} foi removido com sucesso.`,
      })
      setDeleteDialogOpen(false)
    } catch (error) {
      console.error("Erro ao excluir produto:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir o produto",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Atualizar campo do formulário
  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Manipular upload de imagem
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Verificar tipo de arquivo
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Formato não suportado",
        description: "Por favor, selecione uma imagem nos formatos: JPG, PNG, GIF ou WebP",
        variant: "destructive",
      })
      return
    }

    // Verificar tamanho do arquivo (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Arquivo muito grande",
        description: "O tamanho máximo permitido é 5MB",
        variant: "destructive",
      })
      return
    }

    try {
      setUploadingImage(true)

      // Criar preview da imagem
      const reader = new FileReader()
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string)
      }
      reader.readAsDataURL(file)

      // Upload para o Supabase Storage
      const fileName = `produto_${Date.now()}_${file.name.replace(/\s+/g, "_")}`
      const { data, error } = await supabase.storage.from("produtos").upload(fileName, file)

      if (error) throw error

      // Obter URL pública da imagem
      const { data: urlData } = supabase.storage.from("produtos").getPublicUrl(fileName)

      if (urlData) {
        setFormData((prev) => ({
          ...prev,
          imagem: urlData.publicUrl,
        }))
      }

      toast({
        title: "Imagem enviada",
        description: "A imagem foi enviada com sucesso",
      })
    } catch (error) {
      console.error("Erro ao fazer upload da imagem:", error)
      toast({
        title: "Erro no upload",
        description: "Não foi possível enviar a imagem",
        variant: "destructive",
      })
    } finally {
      setUploadingImage(false)
    }
  }

  // Salvar produto (novo ou editado)
  const handleSave = async () => {
    try {
      setLoading(true)

      if (!formData.titulo.trim()) {
        toast({
          title: "Título obrigatório",
          description: "Por favor, informe o título do produto",
          variant: "destructive",
        })
        return
      }

      if (formData.preco <= 0) {
        toast({
          title: "Preço inválido",
          description: "O preço deve ser maior que zero",
          variant: "destructive",
        })
        return
      }

      if (!formData.categoria_id) {
        toast({
          title: "Categoria obrigatória",
          description: "Por favor, selecione uma categoria",
        })
        return
      }

      const produtoData = {
        titulo: formData.titulo,
        descricao: formData.descricao,
        preco: formData.preco,
        desconto: formData.desconto || null,
        tipo: formData.tipo,
        categoria_id: formData.categoria_id,
        imagem: formData.imagem || null,
        destaque: formData.destaque,
        disponivel: formData.disponivel,
      }

      if (currentProduto) {
        // Editar produto existente
        const { error } = await supabase.from("produtos").update(produtoData).eq("id", currentProduto.id)

        if (error) throw error

        // Atualizar estado local
        setProdutos((prev) =>
          prev.map((p) => {
            if (p.id === currentProduto.id) {
              return {
                ...p,
                titulo: formData.titulo,
                descricao: formData.descricao,
                preco: formData.preco,
                desconto: formData.desconto,
                tipo: formData.tipo as "Vegetariano" | "Não Vegetariano",
                categoria: formData.categoria_id,
                image: formData.imagem,
                destaque: formData.destaque,
                disponivel: formData.disponivel,
              }
            }
            return p
          }),
        )

        toast({
          title: "Produto atualizado",
          description: `${formData.titulo} foi atualizado com sucesso.`,
        })
      } else {
        // Adicionar novo produto
        const { data, error } = await supabase.from("produtos").insert(produtoData).select()

        if (error) throw error

        if (data && data.length > 0) {
          // Adicionar novo produto ao estado local
          setProdutos((prev) => [
            ...prev,
            {
              id: data[0].id,
              titulo: data[0].titulo,
              descricao: data[0].descricao,
              preco: data[0].preco,
              desconto: data[0].desconto || 0,
              tipo: data[0].tipo as "Vegetariano" | "Não Vegetariano",
              categoria: data[0].categoria_id,
              image: data[0].imagem || "/placeholder.svg?height=200&width=200",
              quantidade: 0,
              destaque: data[0].destaque || false,
              disponivel: data[0].disponivel !== false,
            },
          ])
        }

        toast({
          title: "Produto adicionado",
          description: `${formData.titulo} foi adicionado com sucesso.`,
        })
      }

      setDialogOpen(false)
    } catch (error) {
      console.error("Erro ao salvar produto:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar o produto",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciar Produtos</h1>
              <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Novo Produto
              </Button>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
              <div className="p-4 border-b dark:border-gray-700 flex items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Pesquisar produtos..."
                    className="pl-10 dark:bg-gray-700 dark:border-gray-600"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="dark:border-gray-700">
                      <TableHead className="dark:text-gray-300">Imagem</TableHead>
                      <TableHead className="dark:text-gray-300">Nome</TableHead>
                      <TableHead className="dark:text-gray-300">Preço</TableHead>
                      <TableHead className="dark:text-gray-300">Desconto</TableHead>
                      <TableHead className="dark:text-gray-300">Tipo</TableHead>
                      <TableHead className="dark:text-gray-300">Categoria</TableHead>
                      <TableHead className="dark:text-gray-300">Status</TableHead>
                      <TableHead className="dark:text-gray-300">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {produtosFiltrados.map((produto) => (
                      <TableRow key={produto.id} className="dark:border-gray-700">
                        <TableCell>
                          <img
                            src={produto.image || "/placeholder.svg?height=40&width=40"}
                            alt={produto.titulo}
                            className="w-10 h-10 rounded-md object-cover"
                          />
                        </TableCell>
                        <TableCell className="font-medium dark:text-white">{produto.titulo}</TableCell>
                        <TableCell className="dark:text-gray-300">R${produto.preco.toFixed(2)}</TableCell>
                        <TableCell className="dark:text-gray-300">
                          {produto.desconto ? `${produto.desconto}%` : "-"}
                        </TableCell>
                        <TableCell className="dark:text-gray-300">
                          <span
                            className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                              produto.tipo === "Vegetariano"
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
                            }`}
                          >
                            {produto.tipo}
                          </span>
                        </TableCell>
                        <TableCell className="dark:text-gray-300">
                          {getCategoriaById(produto.categoria)?.nome || "-"}
                        </TableCell>
                        <TableCell className="dark:text-gray-300">
                          <span
                            className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                              produto.disponivel
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300"
                            }`}
                          >
                            {produto.disponivel ? "Disponível" : "Indisponível"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(produto)}>
                              <Pencil className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteConfirm(produto)}>
                              <Trash2 className="h-4 w-4 text-red-600 dark:text-red-400" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {produtosFiltrados.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8 text-gray-500 dark:text-gray-400">
                          Nenhum produto encontrado
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Diálogo para adicionar/editar produto */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">
              {currentProduto ? "Editar Produto" : "Adicionar Novo Produto"}
            </DialogTitle>
            <DialogDescription className="dark:text-gray-400">Preencha os detalhes do produto abaixo</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-1">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-full h-40 bg-gray-100 dark:bg-gray-800 rounded-md flex items-center justify-center overflow-hidden">
                    {imagePreview ? (
                      <img
                        src={imagePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <ImageIcon className="h-12 w-12 text-gray-400" />
                    )}
                  </div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/jpeg,image/png,image/gif,image/webp"
                    onChange={handleImageUpload}
                  />
                  <Button
                    variant="outline"
                    className="w-full dark:border-gray-700 dark:text-gray-300"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingImage}
                  >
                    {uploadingImage ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Enviar Imagem
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                    Formatos: JPG, PNG, GIF, WebP
                    <br />
                    Tamanho máximo: 5MB
                  </p>
                </div>
              </div>

              <div className="md:col-span-2 space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="titulo" className="dark:text-gray-300">
                    Nome do Produto
                  </Label>
                  <Input
                    id="titulo"
                    value={formData.titulo}
                    onChange={(e) => handleFormChange("titulo", e.target.value)}
                    className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="descricao" className="dark:text-gray-300">
                    Descrição
                  </Label>
                  <Textarea
                    id="descricao"
                    value={formData.descricao}
                    onChange={(e) => handleFormChange("descricao", e.target.value)}
                    className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="preco" className="dark:text-gray-300">
                      Preço (R$)
                    </Label>
                    <Input
                      id="preco"
                      type="number"
                      step="0.01"
                      value={formData.preco}
                      onChange={(e) => handleFormChange("preco", Number.parseFloat(e.target.value))}
                      className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="desconto" className="dark:text-gray-300">
                      Desconto (%)
                    </Label>
                    <Input
                      id="desconto"
                      type="number"
                      value={formData.desconto || ""}
                      onChange={(e) =>
                        handleFormChange("desconto", e.target.value ? Number.parseInt(e.target.value) : 0)
                      }
                      className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="tipo" className="dark:text-gray-300">
                      Tipo
                    </Label>
                    <Select value={formData.tipo} onValueChange={(value) => handleFormChange("tipo", value)}>
                      <SelectTrigger id="tipo" className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                        <SelectItem value="Vegetariano">Vegetariano</SelectItem>
                        <SelectItem value="Não Vegetariano">Não Vegetariano</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="categoria" className="dark:text-gray-300">
                      Categoria
                    </Label>
                    <Select
                      value={formData.categoria_id}
                      onValueChange={(value) => handleFormChange("categoria_id", value)}
                    >
                      <SelectTrigger id="categoria" className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                        <SelectValue placeholder="Selecione a categoria" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                        {categorias.map((categoria) => (
                          <SelectItem key={categoria.id} value={categoria.id}>
                            {categoria.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex flex-col gap-4 sm:flex-row sm:justify-between">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="destaque"
                      checked={formData.destaque}
                      onCheckedChange={(checked) => handleFormChange("destaque", checked)}
                    />
                    <Label htmlFor="destaque" className="dark:text-gray-300">
                      Produto em Destaque
                    </Label>
                  </div>

                  <div className="flex items-center gap-2">
                    <Switch
                      id="disponivel"
                      checked={formData.disponivel}
                      onCheckedChange={(checked) => handleFormChange("disponivel", checked)}
                    />
                    <Label htmlFor="disponivel" className="dark:text-gray-300">
                      Produto Disponível
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Salvando..." : currentProduto ? "Atualizar" : "Adicionar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Confirmar Exclusão</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>

          {currentProduto && (
            <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <img
                src={currentProduto.image || "/placeholder.svg?height=40&width=40"}
                alt={currentProduto.titulo}
                className="w-12 h-12 rounded-md object-cover"
              />
              <div>
                <p className="font-medium dark:text-white">{currentProduto.titulo}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  R${currentProduto.preco.toFixed(2)} • {currentProduto.tipo}
                </p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                if (currentProduto) {
                  handleFormChange("disponivel", false)
                  setCurrentProduto({ ...currentProduto, disponivel: false })
                  handleSave()
                  setDeleteDialogOpen(false)
                }
              }}
              disabled={loading}
            >
              Marcar como Indisponível
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
