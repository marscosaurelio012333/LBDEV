"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { ArrowRight, Package, Users, Calendar, TrendingUp, ShoppingCart } from "lucide-react"
import Link from "next/link"
import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function AdminDashboard() {
  const { user, isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()

  // Verificar se o usuário tem permissão para acessar o painel admin
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
    } else if (!checkPermission("permissao_admin")) {
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router])

  if (!isAuthenticated || !user) {
    return null // Não renderizar nada enquanto verifica autenticação
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-2xl font-bold mb-6 dark:text-white">Painel Administrativo</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">
                    Total de Produtos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold dark:text-white">42</div>
                    <div className="p-2 bg-green-100 dark:bg-green-900 rounded-full">
                      <Package className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Clientes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold dark:text-white">128</div>
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-full">
                      <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Reservas Hoje</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold dark:text-white">8</div>
                    <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-full">
                      <Calendar className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">Vendas Hoje</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-2xl font-bold dark:text-white">R$1.254,00</div>
                    <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-full">
                      <TrendingUp className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="dark:text-white">Acesso Rápido</CardTitle>
                  <CardDescription className="dark:text-gray-400">Acesse as principais funcionalidades</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 gap-4">
                  <Link href="/admin/produtos">
                    <Button variant="outline" className="w-full justify-between dark:border-gray-700 dark:text-white">
                      Gerenciar Produtos
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>

                  {checkPermission("permissao_reservas") && (
                    <Link href="/reservas">
                      <Button variant="outline" className="w-full justify-between dark:border-gray-700 dark:text-white">
                        Gerenciar Reservas
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  )}

                  {checkPermission("permissao_entregas") && (
                    <Link href="/entregas">
                      <Button variant="outline" className="w-full justify-between dark:border-gray-700 dark:text-white">
                        Gerenciar Entregas
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  )}

                  {checkPermission("permissao_contabilidade") && (
                    <Link href="/contabilidade">
                      <Button variant="outline" className="w-full justify-between dark:border-gray-700 dark:text-white">
                        Relatórios Financeiros
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>

              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="dark:text-white">Pedidos Recentes</CardTitle>
                  <CardDescription className="dark:text-gray-400">Últimos 5 pedidos realizados</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                        <div className="p-2 bg-green-100 dark:bg-green-900 rounded-full">
                          <ShoppingCart className="h-4 w-4 text-green-600 dark:text-green-400" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <span className="font-medium dark:text-white">Pedido #{1000 + i}</span>
                            <span className="text-sm text-gray-500 dark:text-gray-400">
                              R${(Math.random() * 100 + 50).toFixed(2)}
                            </span>
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            Mesa {i} • {new Date().toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
