"use client"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Plus, Pencil, Trash2, Search, ArrowUpDown } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase"

// Tipo para categoria
type Categoria = {
  id: string
  nome: string
  icone: string
  ordem: number
  ativa: boolean
}

// Ícones disponíveis
const iconesDisponiveis = [
  { valor: "utensils", nome: "Talheres" },
  { valor: "coffee", nome: "Café" },
  { valor: "soup", nome: "Sopa" },
  { valor: "pasta", nome: "Massa" },
  { valor: "dish", nome: "Prato" },
  { valor: "sandwich", nome: "Sanduíche" },
  { valor: "pizza", nome: "Pizza" },
  { valor: "cake", nome: "Bolo" },
  { valor: "ice-cream", nome: "Sorvete" },
  { valor: "beer", nome: "Cerveja" },
  { valor: "wine", nome: "Vinho" },
  { valor: "fruit", nome: "Fruta" },
]

export default function GerenciarCategorias() {
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentCategoria, setCurrentCategoria] = useState<Categoria | null>(null)
  const [formData, setFormData] = useState({
    id: "",
    nome: "",
    icone: "utensils",
    ordem: 0,
    ativa: true,
  })
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()
  const { isAuthenticated, checkPermission } = useAuth()
  const router = useRouter()
  const supabase = getSupabaseClient()

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    if (!checkPermission("permissao_admin")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
    }
  }, [isAuthenticated, checkPermission, router, toast])

  // Carregar categorias
  useEffect(() => {
    async function fetchCategorias() {
      try {
        setLoading(true)
        const { data, error } = await supabase.from("categorias").select("*").order("ordem")

        if (error) throw error

        if (data) {
          setCategorias(data)
        }
      } catch (error) {
        console.error("Erro ao carregar categorias:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as categorias",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchCategorias()
  }, [supabase, toast])

  // Filtrar categorias com base no termo de pesquisa
  const categoriasFiltradas = categorias.filter(
    (categoria) =>
      categoria.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      categoria.icone.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Abrir diálogo para adicionar nova categoria
  const handleAddNew = () => {
    setCurrentCategoria(null)
    setFormData({
      id: "",
      nome: "",
      icone: "utensils",
      ordem: categorias.length + 1,
      ativa: true,
    })
    setDialogOpen(true)
  }

  // Abrir diálogo para editar categoria existente
  const handleEdit = (categoria: Categoria) => {
    setCurrentCategoria(categoria)
    setFormData({
      ...categoria,
    })
    setDialogOpen(true)
  }

  // Abrir diálogo para confirmar exclusão
  const handleDeleteConfirm = (categoria: Categoria) => {
    setCurrentCategoria(categoria)
    setDeleteDialogOpen(true)
  }

  // Excluir categoria
  const handleDelete = async () => {
    if (!currentCategoria) return

    try {
      setLoading(true)
      const { error } = await supabase.from("categorias").delete().eq("id", currentCategoria.id)

      if (error) throw error

      setCategorias((prev) => prev.filter((c) => c.id !== currentCategoria.id))
      toast({
        title: "Categoria excluída",
        description: `${currentCategoria.nome} foi removida com sucesso.`,
      })
      setDeleteDialogOpen(false)
    } catch (error) {
      console.error("Erro ao excluir categoria:", error)
      toast({
        title: "Erro",
        description: "Não foi possível excluir a categoria",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Atualizar campo do formulário
  const handleFormChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Salvar categoria (nova ou editada)
  const handleSave = async () => {
    try {
      setLoading(true)

      if (!formData.nome.trim()) {
        toast({
          title: "Nome obrigatório",
          description: "Por favor, informe o nome da categoria",
          variant: "destructive",
        })
        return
      }

      if (currentCategoria) {
        // Editar categoria existente
        const { error } = await supabase
          .from("categorias")
          .update({
            nome: formData.nome,
            icone: formData.icone,
            ordem: formData.ordem,
            ativa: formData.ativa,
          })
          .eq("id", currentCategoria.id)

        if (error) throw error

        setCategorias((prev) =>
          prev.map((c) => (c.id === currentCategoria.id ? { ...formData, id: currentCategoria.id } : c)),
        )

        toast({
          title: "Categoria atualizada",
          description: `${formData.nome} foi atualizada com sucesso.`,
        })
      } else {
        // Adicionar nova categoria
        const { data, error } = await supabase
          .from("categorias")
          .insert({
            nome: formData.nome,
            icone: formData.icone,
            ordem: formData.ordem,
            ativa: formData.ativa,
          })
          .select()

        if (error) throw error

        if (data && data.length > 0) {
          setCategorias((prev) => [...prev, data[0]])
        }

        toast({
          title: "Categoria adicionada",
          description: `${formData.nome} foi adicionada com sucesso.`,
        })
      }

      setDialogOpen(false)
    } catch (error) {
      console.error("Erro ao salvar categoria:", error)
      toast({
        title: "Erro",
        description: "Não foi possível salvar a categoria",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Mover categoria para cima ou para baixo na ordem
  const handleMoveCategoria = async (categoria: Categoria, direcao: "cima" | "baixo") => {
    try {
      const novaOrdem = direcao === "cima" ? categoria.ordem - 1 : categoria.ordem + 1

      // Verificar se a nova ordem é válida
      if (novaOrdem < 1 || novaOrdem > categorias.length) return

      // Encontrar categoria que está na posição de destino
      const categoriaAlvo = categorias.find((c) => c.ordem === novaOrdem)

      if (!categoriaAlvo) return

      // Atualizar ordem da categoria atual
      const { error: error1 } = await supabase.from("categorias").update({ ordem: novaOrdem }).eq("id", categoria.id)

      if (error1) throw error1

      // Atualizar ordem da categoria alvo
      const { error: error2 } = await supabase
        .from("categorias")
        .update({ ordem: categoria.ordem })
        .eq("id", categoriaAlvo.id)

      if (error2) throw error2

      // Atualizar estado local
      setCategorias((prev) => {
        const updated = [...prev]
        const index1 = updated.findIndex((c) => c.id === categoria.id)
        const index2 = updated.findIndex((c) => c.id === categoriaAlvo.id)

        if (index1 !== -1 && index2 !== -1) {
          updated[index1] = { ...updated[index1], ordem: novaOrdem }
          updated[index2] = { ...updated[index2], ordem: categoria.ordem }
        }

        return updated.sort((a, b) => a.ordem - b.ordem)
      })
    } catch (error) {
      console.error("Erro ao mover categoria:", error)
      toast({
        title: "Erro",
        description: "Não foi possível reordenar as categorias",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciar Categorias</h1>
              <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Nova Categoria
              </Button>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
              <div className="p-4 border-b dark:border-gray-700 flex items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Pesquisar categorias..."
                    className="pl-10 dark:bg-gray-700 dark:border-gray-600"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="dark:border-gray-700">
                      <TableHead className="dark:text-gray-300">Ordem</TableHead>
                      <TableHead className="dark:text-gray-300">Nome</TableHead>
                      <TableHead className="dark:text-gray-300">Ícone</TableHead>
                      <TableHead className="dark:text-gray-300">Status</TableHead>
                      <TableHead className="dark:text-gray-300">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoriasFiltradas.map((categoria) => (
                      <TableRow key={categoria.id} className="dark:border-gray-700">
                        <TableCell className="dark:text-gray-300">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleMoveCategoria(categoria, "cima")}
                              disabled={categoria.ordem === 1}
                              className="h-6 w-6"
                            >
                              <ArrowUpDown className="h-4 w-4 rotate-90 text-gray-500" />
                            </Button>
                            {categoria.ordem}
                          </div>
                        </TableCell>
                        <TableCell className="font-medium dark:text-white">{categoria.nome}</TableCell>
                        <TableCell className="dark:text-gray-300">{categoria.icone}</TableCell>
                        <TableCell className="dark:text-gray-300">
                          <span
                            className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                              categoria.ativa
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300"
                            }`}
                          >
                            {categoria.ativa ? "Ativa" : "Inativa"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(categoria)}>
                              <Pencil className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteConfirm(categoria)}>
                              <Trash2 className="h-4 w-4 text-red-600 dark:text-red-400" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {categoriasFiltradas.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-gray-500 dark:text-gray-400">
                          Nenhuma categoria encontrada
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Diálogo para adicionar/editar categoria */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">
              {currentCategoria ? "Editar Categoria" : "Adicionar Nova Categoria"}
            </DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Preencha os detalhes da categoria abaixo
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="nome" className="dark:text-gray-300">
                Nome da Categoria
              </Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => handleFormChange("nome", e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="icone" className="dark:text-gray-300">
                Ícone
              </Label>
              <Select value={formData.icone} onValueChange={(value) => handleFormChange("icone", value)}>
                <SelectTrigger id="icone" className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                  <SelectValue placeholder="Selecione um ícone" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                  {iconesDisponiveis.map((icone) => (
                    <SelectItem key={icone.valor} value={icone.valor}>
                      {icone.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="ordem" className="dark:text-gray-300">
                Ordem
              </Label>
              <Input
                id="ordem"
                type="number"
                min="1"
                value={formData.ordem}
                onChange={(e) => handleFormChange("ordem", Number.parseInt(e.target.value))}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="ativa" className="dark:text-gray-300">
                Categoria Ativa
              </Label>
              <Switch
                id="ativa"
                checked={formData.ativa}
                onCheckedChange={(checked) => handleFormChange("ativa", checked)}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Salvando..." : currentCategoria ? "Atualizar" : "Adicionar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para confirmar exclusão */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Confirmar Exclusão</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Tem certeza que deseja excluir esta categoria? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>

          {currentCategoria && (
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p className="font-medium dark:text-white">{currentCategoria.nome}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Ícone: {currentCategoria.icone} • Ordem: {currentCategoria.ordem}
              </p>
            </div>
          )}

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading ? "Excluindo..." : "Excluir"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
