"use client"

import { Badge } from "@/components/ui/badge"

import { useState, useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { getSupabaseClient, type Usuario } from "@/lib/supabase"
import { User, UserPlus, Edit, Trash2, Search, RefreshCw } from "lucide-react"

export default function UsuariosPage() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [novoUsuarioDialogOpen, setNovoUsuarioDialogOpen] = useState(false)
  const [editarUsuarioDialogOpen, setEditarUsuarioDialogOpen] = useState(false)
  const [usuarioAtual, setUsuarioAtual] = useState<Usuario | null>(null)
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    senha: "",
    cargo: "",
    permissao_admin: false,
    permissao_mesas: false,
    permissao_reservas: false,
    permissao_entregas: false,
    permissao_contabilidade: false,
    permissao_configuracoes: false,
    permissao_cozinha: false,
    ativo: true,
  })

  const { toast } = useToast()
  const auth = useAuth()
  const router = useRouter()
  const supabase = getSupabaseClient()

  // Verificar permissão
  useEffect(() => {
    if (!auth.isAuthenticated) {
      router.push("/login")
      return
    }

    if (!auth.checkPermission("permissao_admin")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      router.push("/")
      return
    }

    fetchUsuarios()
  }, [auth, router, toast])

  // Buscar usuários
  const fetchUsuarios = async () => {
    try {
      setLoading(true)
      const { data, error } = await supabase.from("usuarios").select("*").order("nome")

      if (error) throw error

      if (data) {
        setUsuarios(data as Usuario[])
      }
    } catch (error) {
      console.error("Erro ao buscar usuários:", error)
      toast({
        title: "Erro ao carregar usuários",
        description: "Não foi possível carregar a lista de usuários",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Filtrar usuários
  const usuariosFiltrados = usuarios.filter(
    (usuario) =>
      usuario.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      usuario.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (usuario.cargo && usuario.cargo.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  // Abrir diálogo para criar novo usuário
  const handleNovoUsuario = () => {
    setFormData({
      nome: "",
      email: "",
      senha: "",
      cargo: "",
      permissao_admin: false,
      permissao_mesas: false,
      permissao_reservas: false,
      permissao_entregas: false,
      permissao_contabilidade: false,
      permissao_configuracoes: false,
      permissao_cozinha: false,
      ativo: true,
    })
    setNovoUsuarioDialogOpen(true)
  }

  // Abrir diálogo para editar usuário
  const handleEditarUsuario = (usuario: Usuario) => {
    setUsuarioAtual(usuario)
    setFormData({
      nome: usuario.nome,
      email: usuario.email,
      senha: "",
      cargo: usuario.cargo || "",
      permissao_admin: usuario.permissao_admin,
      permissao_mesas: usuario.permissao_mesas,
      permissao_reservas: usuario.permissao_reservas,
      permissao_entregas: usuario.permissao_entregas,
      permissao_contabilidade: usuario.permissao_contabilidade,
      permissao_configuracoes: usuario.permissao_configuracoes,
      permissao_cozinha: usuario.permissao_cozinha || false,
      ativo: usuario.ativo,
    })
    setEditarUsuarioDialogOpen(true)
  }

  // Criar novo usuário
  const handleCriarUsuario = async () => {
    // Validar campos obrigatórios
    if (!formData.nome || !formData.email || !formData.senha || !formData.cargo) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    try {
      // Criar usuário no Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.senha,
      })

      if (authError) throw authError

      if (!authData.user) {
        throw new Error("Erro ao criar usuário na autenticação")
      }

      // Criar usuário na tabela personalizada
      const { data, error } = await supabase.from("usuarios").insert([
        {
          id: authData.user.id,
          nome: formData.nome,
          email: formData.email,
          cargo: formData.cargo,
          permissao_admin: formData.permissao_admin,
          permissao_mesas: formData.permissao_mesas,
          permissao_reservas: formData.permissao_reservas,
          permissao_entregas: formData.permissao_entregas,
          permissao_contabilidade: formData.permissao_contabilidade,
          permissao_configuracoes: formData.permissao_configuracoes,
          permissao_cozinha: formData.permissao_cozinha,
          ativo: formData.ativo,
        },
      ])

      if (error) throw error

      // Atualizar lista de usuários
      fetchUsuarios()
      setNovoUsuarioDialogOpen(false)

      toast({
        title: "Usuário criado",
        description: `Usuário ${formData.nome} foi criado com sucesso`,
      })
    } catch (error) {
      console.error("Erro ao criar usuário:", error)
      toast({
        title: "Erro ao criar usuário",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao criar o usuário",
        variant: "destructive",
      })
    }
  }

  // Atualizar usuário
  const handleAtualizarUsuario = async () => {
    if (!usuarioAtual) return

    // Validar campos obrigatórios
    if (!formData.nome || !formData.email || !formData.cargo) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      })
      return
    }

    try {
      // Atualizar usuário na tabela personalizada
      const updateData = {
        nome: formData.nome,
        email: formData.email,
        cargo: formData.cargo,
        permissao_admin: formData.permissao_admin,
        permissao_mesas: formData.permissao_mesas,
        permissao_reservas: formData.permissao_reservas,
        permissao_entregas: formData.permissao_entregas,
        permissao_contabilidade: formData.permissao_contabilidade,
        permissao_configuracoes: formData.permissao_configuracoes,
        permissao_cozinha: formData.permissao_cozinha,
        ativo: formData.ativo,
      }

      const { error } = await supabase.from("usuarios").update(updateData).eq("id", usuarioAtual.id)

      if (error) throw error

      // Se a senha foi alterada, atualizar no Auth
      if (formData.senha) {
        // Atualizar senha no Auth (requer função personalizada no backend)
        const { error: passwordError } = await supabase.rpc("change_user_password", {
          user_id: usuarioAtual.id,
          new_password: formData.senha,
        })

        if (passwordError) {
          console.warn("Não foi possível atualizar a senha:", passwordError)
          toast({
            title: "Aviso",
            description: "Usuário atualizado, mas não foi possível alterar a senha",
            variant: "default",
          })
        }
      }

      // Atualizar lista de usuários
      fetchUsuarios()
      setEditarUsuarioDialogOpen(false)

      toast({
        title: "Usuário atualizado",
        description: `Usuário ${formData.nome} foi atualizado com sucesso`,
      })
    } catch (error) {
      console.error("Erro ao atualizar usuário:", error)
      toast({
        title: "Erro ao atualizar usuário",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao atualizar o usuário",
        variant: "destructive",
      })
    }
  }

  // Excluir usuário
  const handleExcluirUsuario = async (usuario: Usuario) => {
    if (!confirm(`Tem certeza que deseja excluir o usuário ${usuario.nome}?`)) {
      return
    }

    try {
      // Excluir usuário da tabela personalizada
      const { error } = await supabase.from("usuarios").delete().eq("id", usuario.id)

      if (error) throw error

      // Excluir usuário do Auth (requer função personalizada no backend)
      const { error: authError } = await supabase.rpc("delete_user_auth", {
        user_id: usuario.id,
      })

      if (authError) {
        console.warn("Não foi possível excluir o usuário da autenticação:", authError)
        toast({
          title: "Aviso",
          description: "Usuário excluído do sistema, mas não da autenticação",
          variant: "default",
        })
      }

      // Atualizar lista de usuários
      fetchUsuarios()

      toast({
        title: "Usuário excluído",
        description: `Usuário ${usuario.nome} foi excluído com sucesso`,
      })
    } catch (error) {
      console.error("Erro ao excluir usuário:", error)
      toast({
        title: "Erro ao excluir usuário",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao excluir o usuário",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Gerenciamento de Usuários</h1>
              <div className="flex gap-2">
                <Button variant="outline" className="dark:border-gray-700 dark:text-gray-300" onClick={fetchUsuarios}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Atualizar
                </Button>
                <Button className="bg-green-600 hover:bg-green-700" onClick={handleNovoUsuario}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Novo Usuário
                </Button>
              </div>
            </div>

            <div className="mb-6 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar por nome, email ou cargo..."
                className="pl-10 dark:bg-gray-800 dark:border-gray-700"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {loading ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <div className="animate-spin h-8 w-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                <h3 className="text-xl font-medium dark:text-white mb-2">Carregando usuários</h3>
                <p className="text-gray-500 dark:text-gray-400">Aguarde enquanto buscamos as informações...</p>
              </div>
            ) : usuarios.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center">
                <User className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-xl font-medium dark:text-white mb-2">Nenhum usuário cadastrado</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-6">
                  Para começar a usar o sistema, adicione usuários ao seu restaurante.
                </p>
                <Button onClick={handleNovoUsuario} className="bg-green-600 hover:bg-green-700">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Adicionar Primeiro Usuário
                </Button>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="dark:border-gray-700">
                      <TableHead className="dark:text-gray-300">Nome</TableHead>
                      <TableHead className="dark:text-gray-300">Email</TableHead>
                      <TableHead className="dark:text-gray-300">Cargo</TableHead>
                      <TableHead className="dark:text-gray-300">Permissões</TableHead>
                      <TableHead className="dark:text-gray-300">Status</TableHead>
                      <TableHead className="dark:text-gray-300 text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usuariosFiltrados.map((usuario) => (
                      <TableRow key={usuario.id} className="dark:border-gray-700">
                        <TableCell className="font-medium dark:text-white">{usuario.nome}</TableCell>
                        <TableCell className="dark:text-gray-300">{usuario.email}</TableCell>
                        <TableCell className="dark:text-gray-300">{usuario.cargo}</TableCell>
                        <TableCell className="dark:text-gray-300">
                          <div className="flex flex-wrap gap-1">
                            {usuario.permissao_admin && (
                              <Badge variant="outline" className="border-purple-500 text-purple-500">
                                Admin
                              </Badge>
                            )}
                            {usuario.permissao_contabilidade && (
                              <Badge variant="outline" className="border-green-500 text-green-500">
                                Contabilidade
                              </Badge>
                            )}
                            {usuario.permissao_entregas && (
                              <Badge variant="outline" className="border-blue-500 text-blue-500">
                                Entregas
                              </Badge>
                            )}
                            {usuario.permissao_cozinha && (
                              <Badge variant="outline" className="border-orange-500 text-orange-500">
                                Cozinha
                              </Badge>
                            )}
                            {usuario.permissao_mesas && (
                              <Badge variant="outline" className="border-red-500 text-red-500">
                                Mesas
                              </Badge>
                            )}
                            {usuario.permissao_reservas && (
                              <Badge variant="outline" className="border-yellow-500 text-yellow-500">
                                Reservas
                              </Badge>
                            )}
                            {usuario.permissao_configuracoes && (
                              <Badge variant="outline" className="border-indigo-500 text-indigo-500">
                                Configurações
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="dark:text-gray-300">
                          <Badge
                            variant="outline"
                            className={
                              usuario.ativo ? "border-green-500 text-green-500" : "border-red-500 text-red-500"
                            }
                          >
                            {usuario.ativo ? "Ativo" : "Inativo"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditarUsuario(usuario)}
                              className="h-8 w-8 dark:text-gray-300 dark:hover:bg-gray-700"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleExcluirUsuario(usuario)}
                              className="h-8 w-8 text-red-500 dark:hover:bg-gray-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Diálogo para criar novo usuário */}
      <Dialog open={novoUsuarioDialogOpen} onOpenChange={setNovoUsuarioDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Adicionar Novo Usuário</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Preencha as informações para adicionar um novo usuário ao sistema
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="nome" className="dark:text-gray-300">
                Nome*
              </Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                placeholder="Nome completo"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="email" className="dark:text-gray-300">
                Email*
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                placeholder="email@exemplo.com"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="senha" className="dark:text-gray-300">
                Senha*
              </Label>
              <Input
                id="senha"
                type="password"
                value={formData.senha}
                onChange={(e) => setFormData((prev) => ({ ...prev, senha: e.target.value }))}
                placeholder="Senha segura"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="cargo" className="dark:text-gray-300">
                Cargo*
              </Label>
              <Input
                id="cargo"
                value={formData.cargo}
                onChange={(e) => setFormData((prev) => ({ ...prev, cargo: e.target.value }))}
                placeholder="Ex: Gerente, Atendente, etc."
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label className="dark:text-gray-300">Permissões</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_admin"
                    checked={formData.permissao_admin}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_admin: checked }))}
                  />
                  <Label htmlFor="permissao_admin" className="dark:text-gray-300">
                    Administrador
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_contabilidade"
                    checked={formData.permissao_contabilidade}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, permissao_contabilidade: checked }))
                    }
                  />
                  <Label htmlFor="permissao_contabilidade" className="dark:text-gray-300">
                    Contabilidade
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_entregas"
                    checked={formData.permissao_entregas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_entregas: checked }))}
                  />
                  <Label htmlFor="permissao_entregas" className="dark:text-gray-300">
                    Entregas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_cozinha"
                    checked={formData.permissao_cozinha}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_cozinha: checked }))}
                  />
                  <Label htmlFor="permissao_cozinha" className="dark:text-gray-300">
                    Cozinha
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_mesas"
                    checked={formData.permissao_mesas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_mesas: checked }))}
                  />
                  <Label htmlFor="permissao_mesas" className="dark:text-gray-300">
                    Mesas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_reservas"
                    checked={formData.permissao_reservas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_reservas: checked }))}
                  />
                  <Label htmlFor="permissao_reservas" className="dark:text-gray-300">
                    Reservas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="permissao_configuracoes"
                    checked={formData.permissao_configuracoes}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, permissao_configuracoes: checked }))
                    }
                  />
                  <Label htmlFor="permissao_configuracoes" className="dark:text-gray-300">
                    Configurações
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="ativo"
                    checked={formData.ativo}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, ativo: checked }))}
                  />
                  <Label htmlFor="ativo" className="dark:text-gray-300">
                    Ativo
                  </Label>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setNovoUsuarioDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button onClick={handleCriarUsuario} className="bg-green-600 hover:bg-green-700">
              Criar Usuário
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para editar usuário */}
      <Dialog open={editarUsuarioDialogOpen} onOpenChange={setEditarUsuarioDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Editar Usuário</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Atualize as informações do usuário</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-nome" className="dark:text-gray-300">
                Nome*
              </Label>
              <Input
                id="edit-nome"
                value={formData.nome}
                onChange={(e) => setFormData((prev) => ({ ...prev, nome: e.target.value }))}
                placeholder="Nome completo"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-email" className="dark:text-gray-300">
                Email*
              </Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                placeholder="email@exemplo.com"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-senha" className="dark:text-gray-300">
                Nova Senha (deixe em branco para manter a atual)
              </Label>
              <Input
                id="edit-senha"
                type="password"
                value={formData.senha}
                onChange={(e) => setFormData((prev) => ({ ...prev, senha: e.target.value }))}
                placeholder="Nova senha"
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="edit-cargo" className="dark:text-gray-300">
                Cargo*
              </Label>
              <Input
                id="edit-cargo"
                value={formData.cargo}
                onChange={(e) => setFormData((prev) => ({ ...prev, cargo: e.target.value }))}
                placeholder="Ex: Gerente, Atendente, etc."
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>

            <div className="grid gap-2">
              <Label className="dark:text-gray-300">Permissões</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_admin"
                    checked={formData.permissao_admin}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_admin: checked }))}
                  />
                  <Label htmlFor="edit-permissao_admin" className="dark:text-gray-300">
                    Administrador
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_contabilidade"
                    checked={formData.permissao_contabilidade}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, permissao_contabilidade: checked }))
                    }
                  />
                  <Label htmlFor="edit-permissao_contabilidade" className="dark:text-gray-300">
                    Contabilidade
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_entregas"
                    checked={formData.permissao_entregas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_entregas: checked }))}
                  />
                  <Label htmlFor="edit-permissao_entregas" className="dark:text-gray-300">
                    Entregas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_cozinha"
                    checked={formData.permissao_cozinha}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_cozinha: checked }))}
                  />
                  <Label htmlFor="edit-permissao_cozinha" className="dark:text-gray-300">
                    Cozinha
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_mesas"
                    checked={formData.permissao_mesas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_mesas: checked }))}
                  />
                  <Label htmlFor="edit-permissao_mesas" className="dark:text-gray-300">
                    Mesas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_reservas"
                    checked={formData.permissao_reservas}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, permissao_reservas: checked }))}
                  />
                  <Label htmlFor="edit-permissao_reservas" className="dark:text-gray-300">
                    Reservas
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-permissao_configuracoes"
                    checked={formData.permissao_configuracoes}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, permissao_configuracoes: checked }))
                    }
                  />
                  <Label htmlFor="edit-permissao_configuracoes" className="dark:text-gray-300">
                    Configurações
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-ativo"
                    checked={formData.ativo}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, ativo: checked }))}
                  />
                  <Label htmlFor="edit-ativo" className="dark:text-gray-300">
                    Ativo
                  </Label>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEditarUsuarioDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button onClick={handleAtualizarUsuario} className="bg-blue-600 hover:bg-blue-700">
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
