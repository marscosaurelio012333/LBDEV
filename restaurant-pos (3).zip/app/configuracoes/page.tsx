"use client"

import type React from "react"

import { useState } from "react"
import { useEffect } from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { Save, Building, Bell, Printer, Upload, Smartphone, Loader2 } from "lucide-react"
import { getSupabaseClient } from "@/lib/supabase"

export default function ConfiguracoesPage() {
  const { user, isAuthenticated, checkPermission } = useAuth()
  const { toast } = useToast()
  const [restauranteForm, setRestauranteForm] = useState({
    nome: "Chili Restaurant",
    endereco: "Av. Paulista, 1000 - Bela Vista",
    telefone: "(11) 3456-7890",
    email: "contato@chilirestaurant.com",
    cnpj: "12.345.678/0001-90",
    horarioFuncionamento: "Segunda a Domingo: 11h às 23h",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
  })

  const [notificacoes, setNotificacoes] = useState({
    novoPedido: true,
    novaReserva: true,
    baixoEstoque: true,
    relatoriosDiarios: false,
    emailMarketing: false,
  })

  const [impressora, setImpressora] = useState({
    modelo: "Epson TM-T20",
    tipo: "USB",
    porta: "COM1",
    ip: "",
    impressaoAutomatica: true,
    ativa: true,
    copias: 1,
    cabecalho: "",
    rodape: "",
  })

  const [tema, setTema] = useState("sistema")

  // Add state for restaurant settings and loading
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [logoFile, setLogoFile] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const supabase = getSupabaseClient()

  // Verificar permissão
  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = "/login"
      return
    }

    if (!checkPermission("permissao_configuracoes")) {
      toast({
        title: "Acesso negado",
        description: "Você não tem permissão para acessar esta página",
        variant: "destructive",
      })
      window.location.href = "/"
    }
  }, [isAuthenticated, checkPermission, toast])

  // Add useEffect to load restaurant settings
  useEffect(() => {
    async function loadRestaurantSettings() {
      try {
        setIsLoading(true)

        // Usar try/catch para cada consulta separadamente
        try {
          // Buscar configurações do restaurante
          const { data: restauranteData, error: restauranteError } = await supabase
            .from("configuracoes_restaurante")
            .select("*")
            .limit(1)

          if (restauranteError) {
            console.error("Erro ao buscar configurações do restaurante:", restauranteError)
          } else if (restauranteData && restauranteData.length > 0) {
            setRestauranteForm({
              nome: restauranteData[0].nome || "Chili Restaurant",
              endereco: restauranteData[0].endereco || "Av. Paulista, 1000 - Bela Vista",
              telefone: restauranteData[0].telefone || "(11) 3456-7890",
              email: restauranteData[0].email || "contato@chilirestaurant.com",
              cnpj: restauranteData[0].cnpj || "12.345.678/0001-90",
              horarioFuncionamento: restauranteData[0].horario_funcionamento || "Segunda a Domingo: 11h às 23h",
              logo:
                restauranteData[0].logo_url ||
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
            })

            if (restauranteData[0].logo_url) {
              setLogoPreview(restauranteData[0].logo_url)
            }
          }
        } catch (restauranteError) {
          console.error("Erro ao processar configurações do restaurante:", restauranteError)
        }

        try {
          // Buscar configurações da impressora
          const { data: printerData, error: printerError } = await supabase
            .from("configuracoes_impressora")
            .select("*")
            .limit(1)

          if (printerError) {
            console.error("Erro ao buscar configurações da impressora:", printerError)
          } else if (printerData && printerData.length > 0) {
            setImpressora({
              modelo: printerData[0].modelo || "Epson TM-T20",
              tipo: printerData[0].tipo || "USB",
              porta: printerData[0].porta || "COM1",
              ip: printerData[0].ip || "",
              impressaoAutomatica: printerData[0].impressao_automatica !== false,
              ativa: printerData[0].ativa !== false,
              copias: printerData[0].copias || 1,
              cabecalho: printerData[0].cabecalho || "",
              rodape: printerData[0].rodape || "",
            })
          }
        } catch (printerError) {
          console.error("Erro ao processar configurações da impressora:", printerError)
        }
      } catch (error) {
        console.error("Error loading restaurant settings:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as configurações do restaurante",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadRestaurantSettings()
  }, [supabase, toast])

  // Add function to handle logo file selection
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setLogoFile(file)

      // Create preview
      const reader = new FileReader()
      reader.onload = (event) => {
        if (event.target?.result) {
          setLogoPreview(event.target.result as string)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const handleRestauranteChange = (field: string, value: string) => {
    setRestauranteForm((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleNotificacaoChange = (field: string, value: boolean) => {
    setNotificacoes((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleImpressoraChange = (field: string, value: any) => {
    setImpressora((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Update the handleSaveConfig function to save to database
  const handleSaveConfig = async (tipo: string) => {
    try {
      setIsSaving(true)

      if (tipo === "restaurante") {
        let logoUrl = restauranteForm.logo

        // Upload logo if a new one was selected
        if (logoFile) {
          try {
            const fileName = `logo-${Date.now()}`
            const { data: uploadData, error: uploadError } = await supabase.storage
              .from("logos")
              .upload(fileName, logoFile)

            if (uploadError) throw uploadError

            if (uploadData) {
              // Get public URL
              const { data: urlData } = supabase.storage.from("logos").getPublicUrl(fileName)

              if (urlData) {
                logoUrl = urlData.publicUrl
              }
            }
          } catch (uploadError) {
            console.error("Erro ao fazer upload do logo:", uploadError)
            // Continue com o logo atual se houver erro no upload
          }
        }

        // Check if record exists
        const { data: existingData, error: checkError } = await supabase
          .from("configuracoes_restaurante")
          .select("id")
          .limit(1)

        if (checkError) {
          console.error("Erro ao verificar configurações existentes:", checkError)
          throw checkError
        }

        if (existingData && existingData.length > 0) {
          // Update existing record
          const { error } = await supabase
            .from("configuracoes_restaurante")
            .update({
              nome: restauranteForm.nome,
              endereco: restauranteForm.endereco,
              telefone: restauranteForm.telefone,
              email: restauranteForm.email,
              cnpj: restauranteForm.cnpj,
              horario_funcionamento: restauranteForm.horarioFuncionamento,
              logo_url: logoUrl,
              updated_at: new Date().toISOString(),
            })
            .eq("id", existingData[0].id)

          if (error) throw error
        } else {
          // Insert new record
          const { error: insertError } = await supabase.from("configuracoes_restaurante").insert({
            nome: restauranteForm.nome,
            endereco: restauranteForm.endereco,
            telefone: restauranteForm.telefone,
            email: restauranteForm.email,
            cnpj: restauranteForm.cnpj,
            horario_funcionamento: restauranteForm.horarioFuncionamento,
            logo_url: logoUrl,
          })

          if (insertError) throw insertError
        }
      } else if (tipo === "impressão") {
        // Check if record exists
        const { data: existingData, error: checkError } = await supabase
          .from("configuracoes_impressora")
          .select("id")
          .limit(1)

        if (checkError) {
          console.error("Erro ao verificar configurações da impressora existentes:", checkError)
          throw checkError
        }

        const cabecalhoText = document.getElementById("cabecalho")
          ? (document.getElementById("cabecalho") as HTMLTextAreaElement).value
          : impressora.cabecalho

        const rodapeText = document.getElementById("rodape")
          ? (document.getElementById("rodape") as HTMLTextAreaElement).value
          : impressora.rodape

        if (existingData && existingData.length > 0) {
          // Update existing record
          const { error } = await supabase
            .from("configuracoes_impressora")
            .update({
              modelo: impressora.modelo,
              tipo: impressora.tipo,
              porta: impressora.porta,
              ip: impressora.ip,
              impressao_automatica: impressora.impressaoAutomatica,
              ativa: impressora.ativa,
              copias: impressora.copias,
              cabecalho: cabecalhoText,
              rodape: rodapeText,
              updated_at: new Date().toISOString(),
            })
            .eq("id", existingData[0].id)

          if (error) throw error
        } else {
          // Insert new record
          const { error: insertError } = await supabase.from("configuracoes_impressora").insert({
            modelo: impressora.modelo,
            tipo: impressora.tipo,
            porta: impressora.porta,
            ip: impressora.ip,
            impressao_automatica: impressora.impressaoAutomatica,
            ativa: impressora.ativa,
            copias: impressora.copias,
            cabecalho: cabecalhoText,
            rodape: rodapeText,
          })

          if (insertError) throw insertError
        }
      }

      toast({
        title: "Configurações salvas",
        description: `As configurações de ${tipo} foram salvas com sucesso.`,
      })
    } catch (error) {
      console.error(`Error saving ${tipo} settings:`, error)
      toast({
        title: "Erro",
        description: `Não foi possível salvar as configurações de ${tipo}`,
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-950 transition-colors">
      <SidebarNav />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-5xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold dark:text-white">Configurações</h1>
            </div>

            <Tabs defaultValue="restaurante" className="space-y-4">
              <TabsList className="dark:bg-gray-800">
                <TabsTrigger value="restaurante" className="dark:data-[state=active]:bg-gray-700">
                  <Building className="h-4 w-4 mr-2" />
                  Restaurante
                </TabsTrigger>
                <TabsTrigger value="notificacoes" className="dark:data-[state=active]:bg-gray-700">
                  <Bell className="h-4 w-4 mr-2" />
                  Notificações
                </TabsTrigger>
                <TabsTrigger value="impressao" className="dark:data-[state=active]:bg-gray-700">
                  <Printer className="h-4 w-4 mr-2" />
                  Impressão
                </TabsTrigger>
                <TabsTrigger value="aparencia" className="dark:data-[state=active]:bg-gray-700">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Aparência
                </TabsTrigger>
              </TabsList>

              <TabsContent value="restaurante">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="dark:text-white">Informações do Restaurante</CardTitle>
                    <CardDescription className="dark:text-gray-400">
                      Atualize as informações básicas do seu estabelecimento
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-col md:flex-row gap-4 items-start">
                      <div className="w-full md:w-1/3 flex flex-col items-center">
                        <img
                          src={logoPreview || restauranteForm.logo || "/placeholder.svg"}
                          alt="Logo do Restaurante"
                          className="w-32 h-32 rounded-lg object-cover mb-2"
                        />
                        <label htmlFor="logo-upload" className="w-full cursor-pointer">
                          <Button
                            variant="outline"
                            className="w-full dark:border-gray-700 dark:text-gray-300"
                            type="button"
                          >
                            {isSaving ? (
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            ) : (
                              <Upload className="h-4 w-4 mr-2" />
                            )}
                            Alterar Logo
                          </Button>
                          <input
                            id="logo-upload"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleLogoChange}
                            disabled={isSaving}
                          />
                        </label>
                      </div>

                      <div className="w-full md:w-2/3 space-y-4">
                        <div className="grid gap-2">
                          <Label htmlFor="nome" className="dark:text-gray-300">
                            Nome do Restaurante
                          </Label>
                          <Input
                            id="nome"
                            value={restauranteForm.nome}
                            onChange={(e) => handleRestauranteChange("nome", e.target.value)}
                            className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          />
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="endereco" className="dark:text-gray-300">
                            Endereço
                          </Label>
                          <Input
                            id="endereco"
                            value={restauranteForm.endereco}
                            onChange={(e) => handleRestauranteChange("endereco", e.target.value)}
                            className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="grid gap-2">
                            <Label htmlFor="telefone" className="dark:text-gray-300">
                              Telefone
                            </Label>
                            <Input
                              id="telefone"
                              value={restauranteForm.telefone}
                              onChange={(e) => handleRestauranteChange("telefone", e.target.value)}
                              className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                            />
                          </div>

                          <div className="grid gap-2">
                            <Label htmlFor="email" className="dark:text-gray-300">
                              Email
                            </Label>
                            <Input
                              id="email"
                              type="email"
                              value={restauranteForm.email}
                              onChange={(e) => handleRestauranteChange("email", e.target.value)}
                              className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="grid gap-2">
                            <Label htmlFor="cnpj" className="dark:text-gray-300">
                              CNPJ
                            </Label>
                            <Input
                              id="cnpj"
                              value={restauranteForm.cnpj}
                              onChange={(e) => handleRestauranteChange("cnpj", e.target.value)}
                              className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                            />
                          </div>

                          <div className="grid gap-2">
                            <Label htmlFor="horario" className="dark:text-gray-300">
                              Horário de Funcionamento
                            </Label>
                            <Input
                              id="horario"
                              value={restauranteForm.horarioFuncionamento}
                              onChange={(e) => handleRestauranteChange("horarioFuncionamento", e.target.value)}
                              className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button
                      onClick={() => handleSaveConfig("restaurante")}
                      className="bg-green-600 hover:bg-green-700"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Salvando...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Salvar Alterações
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="notificacoes">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="dark:text-white">Configurações de Notificações</CardTitle>
                    <CardDescription className="dark:text-gray-400">
                      Gerencie como e quando você recebe notificações
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium dark:text-white">Notificações do Sistema</h3>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Novos Pedidos</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Receba notificações quando novos pedidos forem realizados
                          </p>
                        </div>
                        <Switch
                          checked={notificacoes.novoPedido}
                          onCheckedChange={(value) => handleNotificacaoChange("novoPedido", value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Novas Reservas</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Receba notificações quando novas reservas forem feitas
                          </p>
                        </div>
                        <Switch
                          checked={notificacoes.novaReserva}
                          onCheckedChange={(value) => handleNotificacaoChange("novaReserva", value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Alerta de Estoque Baixo</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Receba notificações quando produtos estiverem com estoque baixo
                          </p>
                        </div>
                        <Switch
                          checked={notificacoes.baixoEstoque}
                          onCheckedChange={(value) => handleNotificacaoChange("baixoEstoque", value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-medium dark:text-white">Notificações por Email</h3>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Relatórios Diários</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Receba relatórios diários de vendas por email
                          </p>
                        </div>
                        <Switch
                          checked={notificacoes.relatoriosDiarios}
                          onCheckedChange={(value) => handleNotificacaoChange("relatoriosDiarios", value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Email Marketing</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Receba atualizações sobre novos recursos e promoções
                          </p>
                        </div>
                        <Switch
                          checked={notificacoes.emailMarketing}
                          onCheckedChange={(value) => handleNotificacaoChange("emailMarketing", value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button
                      onClick={() => handleSaveConfig("notificações")}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Salvar Alterações
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="impressao">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="dark:text-white">Configurações de Impressão</CardTitle>
                    <CardDescription className="dark:text-gray-400">
                      Configure as opções de impressão de pedidos e recibos
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="impressora" className="dark:text-white">
                          Modelo da Impressora
                        </Label>
                        <Select
                          value={impressora.modelo}
                          onValueChange={(value) => handleImpressoraChange("modelo", value)}
                        >
                          <SelectTrigger
                            id="impressora"
                            className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          >
                            <SelectValue placeholder="Selecione o modelo" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                            <SelectItem value="Epson TM-T20">Epson TM-T20</SelectItem>
                            <SelectItem value="Bematech MP-4200">Bematech MP-4200</SelectItem>
                            <SelectItem value="Elgin i9">Elgin i9</SelectItem>
                            <SelectItem value="Daruma DR800">Daruma DR800</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="tipo" className="dark:text-white">
                          Tipo de Conexão
                        </Label>
                        <Select
                          value={impressora.tipo}
                          onValueChange={(value) => handleImpressoraChange("tipo", value)}
                        >
                          <SelectTrigger id="tipo" className="dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                            <SelectItem value="USB">USB</SelectItem>
                            <SelectItem value="Serial">Serial</SelectItem>
                            <SelectItem value="Ethernet">Ethernet</SelectItem>
                            <SelectItem value="Bluetooth">Bluetooth</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {impressora.tipo === "Serial" && (
                        <div className="grid gap-2">
                          <Label htmlFor="porta" className="dark:text-white">
                            Porta
                          </Label>
                          <Input
                            id="porta"
                            value={impressora.porta}
                            onChange={(e) => handleImpressoraChange("porta", e.target.value)}
                            placeholder="Ex: COM1"
                            className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          />
                        </div>
                      )}

                      {impressora.tipo === "Ethernet" && (
                        <div className="grid gap-2">
                          <Label htmlFor="ip" className="dark:text-white">
                            Endereço IP
                          </Label>
                          <Input
                            id="ip"
                            value={impressora.ip}
                            onChange={(e) => handleImpressoraChange("ip", e.target.value)}
                            placeholder="Ex: 192.168.1.100"
                            className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          />
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Status da Impressora</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Ativar ou desativar a impressora</p>
                        </div>
                        <Switch
                          checked={impressora.ativa}
                          onCheckedChange={(value) => handleImpressoraChange("ativa", value)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label className="dark:text-white">Impressão Automática</Label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            Imprimir automaticamente ao finalizar pedido
                          </p>
                        </div>
                        <Switch
                          checked={impressora.impressaoAutomatica}
                          onCheckedChange={(value) => handleImpressoraChange("impressaoAutomatica", value)}
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="copias" className="dark:text-white">
                          Número de Cópias
                        </Label>
                        <Select
                          value={impressora.copias.toString()}
                          onValueChange={(value) => handleImpressoraChange("copias", Number.parseInt(value))}
                        >
                          <SelectTrigger id="copias" className="dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                            <SelectValue placeholder="Selecione o número de cópias" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                            <SelectItem value="1">1 cópia</SelectItem>
                            <SelectItem value="2">2 cópias</SelectItem>
                            <SelectItem value="3">3 cópias</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="cabecalho" className="dark:text-white">
                          Cabeçalho do Recibo
                        </Label>
                        <Textarea
                          id="cabecalho"
                          placeholder="Digite o texto que aparecerá no cabeçalho do recibo"
                          defaultValue={
                            impressora.cabecalho ||
                            `${restauranteForm.nome}\n${restauranteForm.endereco}\nTel: ${restauranteForm.telefone}\nCNPJ: ${restauranteForm.cnpj}`
                          }
                          className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          rows={4}
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="rodape" className="dark:text-white">
                          Rodapé do Recibo
                        </Label>
                        <Textarea
                          id="rodape"
                          placeholder="Digite o texto que aparecerá no rodapé do recibo"
                          defaultValue={impressora.rodape || "Agradecemos a preferência!\nVolte sempre!"}
                          className="dark:bg-gray-900 dark:border-gray-700 dark:text-white"
                          rows={2}
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button onClick={() => handleSaveConfig("impressão")} className="bg-green-600 hover:bg-green-700">
                      <Save className="h-4 w-4 mr-2" />
                      Salvar Alterações
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="aparencia">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="dark:text-white">Configurações de Aparência</CardTitle>
                    <CardDescription className="dark:text-gray-400">Personalize a aparência do sistema</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="tema" className="dark:text-white">
                          Tema
                        </Label>
                        <Select value={tema} onValueChange={setTema}>
                          <SelectTrigger id="tema" className="dark:bg-gray-900 dark:border-gray-700 dark:text-white">
                            <SelectValue placeholder="Selecione o tema" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                            <SelectItem value="claro">Claro</SelectItem>
                            <SelectItem value="escuro">Escuro</SelectItem>
                            <SelectItem value="sistema">Seguir Sistema</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                        <div className="border rounded-lg overflow-hidden dark:border-gray-700">
                          <div className="bg-white p-4 h-32 flex items-center justify-center">
                            <div className="text-center">
                              <span className="text-sm font-medium">Tema Claro</span>
                            </div>
                          </div>
                          <div className="p-2 bg-gray-50 flex justify-center">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setTema("claro")}
                              className={tema === "claro" ? "bg-green-100 text-green-600 border-green-200" : ""}
                            >
                              {tema === "claro" ? "Selecionado" : "Selecionar"}
                            </Button>
                          </div>
                        </div>

                        <div className="border rounded-lg overflow-hidden dark:border-gray-700">
                          <div className="bg-gray-900 p-4 h-32 flex items-center justify-center">
                            <div className="text-center">
                              <span className="text-sm font-medium text-white">Tema Escuro</span>
                            </div>
                          </div>
                          <div className="p-2 bg-gray-800 flex justify-center">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setTema("escuro")}
                              className={
                                tema === "escuro"
                                  ? "bg-green-900 text-green-400 border-green-800"
                                  : "bg-gray-700 text-white border-gray-600"
                              }
                            >
                              {tema === "escuro" ? "Selecionado" : "Selecionar"}
                            </Button>
                          </div>
                        </div>

                        <div className="border rounded-lg overflow-hidden dark:border-gray-700">
                          <div className="bg-gradient-to-b from-white to-gray-900 p-4 h-32 flex items-center justify-center">
                            <div className="text-center">
                              <span className="text-sm font-medium">Seguir Sistema</span>
                            </div>
                          </div>
                          <div className="p-2 bg-gray-100 dark:bg-gray-800 flex justify-center">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setTema("sistema")}
                              className={
                                tema === "sistema"
                                  ? "bg-green-100 text-green-600 border-green-200 dark:bg-green-900 dark:text-green-400 dark:border-green-800"
                                  : ""
                              }
                            >
                              {tema === "sistema" ? "Selecionado" : "Selecionar"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-end">
                    <Button onClick={() => handleSaveConfig("aparência")} className="bg-green-600 hover:bg-green-700">
                      <Save className="h-4 w-4 mr-2" />
                      Salvar Alterações
                    </Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  )
}
