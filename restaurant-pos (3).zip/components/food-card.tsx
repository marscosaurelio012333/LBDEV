"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Minus, Plus, ShoppingCart } from "lucide-react"
import { useState } from "react"
import { useAppContext } from "@/contexts/app-context"

interface FoodCardProps {
  id: string
  name: string
  description?: string
  price: number
  image?: string
  discount?: number
  type?: "Vegetariano" | "Não Vegetariano"
}

export function FoodCard({ id, name, description, price, image, discount, type = "Não Vegetariano" }: FoodCardProps) {
  const [quantidade, setQuantidade] = useState(0)
  const { addToCart } = useAppContext()

  const handleAddToCart = () => {
    if (quantidade > 0) {
      // Adicionar a quantidade selecionada ao carrinho
      for (let i = 0; i < quantidade; i++) {
        addToCart({
          id,
          titulo: name,
          descricao: description || "",
          preco: price,
          image: image || "/placeholder.svg?height=200&width=200",
          tipo: type,
          quantidade: 1,
        })
      }
      setQuantidade(0)
    } else {
      // Adicionar um item ao carrinho
      addToCart({
        id,
        titulo: name,
        descricao: description || "",
        preco: price,
        image: image || "/placeholder.svg?height=200&width=200",
        tipo: type,
        quantidade: 1,
      })
    }
  }

  return (
    <Card className="overflow-hidden dark:bg-gray-800 dark:border-gray-700 transition-all hover:shadow-md">
      <div className="relative">
        <img src={image || "/placeholder.svg?height=200&width=200"} alt={name} className="w-full h-40 object-cover" />
        {discount && discount > 0 && (
          <div className="absolute top-2 left-2 bg-yellow-400 text-black px-2 py-1 rounded-md text-xs font-medium">
            {discount}% Off
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-medium mb-1 dark:text-white">{name}</h3>
        {description && <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 line-clamp-2">{description}</p>}
        <div className="flex justify-between items-center mb-2">
          <span className="text-green-600 dark:text-green-400 font-bold">R${price.toFixed(2)}</span>
          <div className="flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${type === "Vegetariano" ? "bg-green-500" : "bg-red-500"}`}></span>
            <span className="text-xs text-gray-500 dark:text-gray-400">{type}</span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full dark:border-gray-700 dark:text-gray-300"
            onClick={() => setQuantidade(Math.max(0, quantidade - 1))}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="font-medium dark:text-white">{quantidade}</span>
          <Button
            variant="outline"
            size="icon"
            className="rounded-full dark:border-gray-700 dark:text-gray-300"
            onClick={() => setQuantidade(quantidade + 1)}
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            variant="secondary"
            size="sm"
            className="ml-2 bg-green-100 text-green-600 hover:bg-green-200 dark:bg-green-900 dark:text-green-400 dark:hover:bg-green-800"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="h-4 w-4 mr-1" />
            Adicionar
          </Button>
        </div>
      </div>
    </Card>
  )
}
