"use client"

import { useEffect, useState } from "react"
import { useAppContext } from "@/contexts/app-context"
import { Button } from "@/components/ui/button"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { getSupabaseClient } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

type Category = {
  id: string
  nome: string
  icone: string
}

export function CategoryFilter() {
  const appContext = useAppContext()
  const selectedCategory = appContext?.selectedCategory || "todos"
  const setSelectedCategory = appContext?.setSelectedCategory || (() => {})
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)

  // Buscar categorias do banco de dados
  useEffect(() => {
    async function fetchCategorias() {
      try {
        setLoading(true)
        const supabase = getSupabaseClient()

        // Buscar categorias ativas
        const { data, error } = await supabase.from("categorias").select("*").eq("ativa", true).order("ordem")

        if (error) {
          console.error("Erro ao buscar categorias:", error)
          setCategories([])
        } else if (data) {
          // Converter dados do banco para o formato Category
          const formattedCategories: Category[] = data.map((item) => ({
            id: item.id,
            nome: item.nome,
            icone: item.icone,
          }))
          setCategories(formattedCategories)
        }
      } catch (error) {
        console.error("Erro ao buscar categorias:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchCategorias()

    // Configurar atualização em tempo real para categorias
    const supabase = getSupabaseClient()
    const channel = supabase
      .channel("categorias-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "categorias" }, () => {
        fetchCategorias()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  if (loading) {
    return (
      <div className="flex justify-center items-center p-4">
        <Loader2 className="h-6 w-6 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex space-x-2 p-4">
        <Button
          variant={selectedCategory === "todos" ? "default" : "outline"}
          className="rounded-full"
          onClick={() => {
            if (typeof setSelectedCategory === "function") {
              setSelectedCategory("todos")
            } else {
              console.error("setSelectedCategory is not a function")
            }
          }}
        >
          Todos
        </Button>
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            className="rounded-full"
            onClick={() => {
              if (typeof setSelectedCategory === "function") {
                setSelectedCategory(category.id)
              } else {
                console.error("setSelectedCategory is not a function")
              }
            }}
          >
            {category.nome}
          </Button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  )
}
