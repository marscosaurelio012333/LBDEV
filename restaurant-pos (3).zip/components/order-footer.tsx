interface OrderFooterProps {
  mesa: string
  itens: number
  cozinha: string
  status?: string
}

export function OrderFooter({ mesa, itens, cozinha, status }: OrderFooterProps) {
  return (
    <div className="flex items-center gap-2 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
      <div className="w-8 h-8 bg-orange-400 rounded-full flex items-center justify-center text-white font-medium">
        {mesa}
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium dark:text-white">
          {itens} Itens → {cozinha}
        </div>
        {status && <div className="text-xs text-orange-600 dark:text-orange-400">{status}</div>}
      </div>
    </div>
  )
}
