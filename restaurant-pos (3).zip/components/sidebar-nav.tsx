"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useMobile } from "@/hooks/use-mobile"
import { useAuth } from "@/contexts/auth-context"
import {
  Menu,
  ShoppingBag,
  Users,
  Settings,
  LogOut,
  CreditCard,
  Truck,
  CalendarRange,
  LayoutDashboard,
  Table2,
  ChefHat,
  Tag,
  Layers,
  BookOpen,
} from "lucide-react"

export function SidebarNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const isMobile = useMobile()
  const { user, logout, checkPermission } = useAuth()

  const isActive = (path: string) => {
    return pathname === path
  }

  const navItems = [
    {
      title: "Cardápio",
      href: "/",
      icon: <BookOpen className="h-5 w-5" />,
      permission: null,
    },
    {
      title: "Mesas",
      href: "/mesas",
      icon: <Table2 className="h-5 w-5" />,
      permission: null, // Temporariamente removendo a verificação de permissão
    },
    {
      title: "Cozinha",
      href: "/cozinha",
      icon: <ChefHat className="h-5 w-5" />,
      permission: "permissao_cozinha",
    },
    {
      title: "Entregas",
      href: "/entregas",
      icon: <Truck className="h-5 w-5" />,
      permission: "permissao_entregas",
    },
    {
      title: "Reservas",
      href: "/reservas",
      icon: <CalendarRange className="h-5 w-5" />,
      permission: "permissao_reservas",
    },
    {
      title: "Contabilidade",
      href: "/contabilidade",
      icon: <CreditCard className="h-5 w-5" />,
      permission: "permissao_contabilidade",
    },
    {
      title: "Configurações",
      href: "/configuracoes",
      icon: <Settings className="h-5 w-5" />,
      permission: "permissao_configuracoes",
    },
    {
      title: "Painel Admin",
      href: "/admin",
      icon: <LayoutDashboard className="h-5 w-5" />,
      permission: "permissao_admin",
    },
  ]

  const adminItems = [
    {
      title: "Produtos",
      href: "/admin/produtos",
      icon: <ShoppingBag className="h-5 w-5" />,
    },
    {
      title: "Categorias",
      href: "/admin/categorias",
      icon: <Tag className="h-5 w-5" />,
    },
    {
      title: "Usuários",
      href: "/admin/usuarios",
      icon: <Users className="h-5 w-5" />,
    },
  ]

  const renderNavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b dark:border-gray-800">
        <Link href="/" className="flex items-center gap-2">
          <Layers className="h-6 w-6 text-green-600" />
          <span className="font-bold text-xl dark:text-white">Chili POS</span>
        </Link>
      </div>

      <ScrollArea className="flex-1 py-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight dark:text-gray-400">Menu Principal</h2>
          <div className="space-y-1">
            {navItems
              .filter((item) => !item.permission || checkPermission(item.permission))
              .map((item) => (
                <Button
                  key={item.href}
                  variant={isActive(item.href) ? "secondary" : "ghost"}
                  className={`w-full justify-start ${
                    isActive(item.href)
                      ? "bg-green-100 text-green-900 hover:bg-green-200 hover:text-green-900 dark:bg-green-900/20 dark:text-green-50 dark:hover:bg-green-900/30"
                      : "dark:text-gray-400 dark:hover:text-white"
                  }`}
                  asChild
                  onClick={() => isMobile && setOpen(false)}
                >
                  <Link href={item.href}>
                    {item.icon}
                    <span className="ml-2">{item.title}</span>
                  </Link>
                </Button>
              ))}
          </div>
        </div>

        {checkPermission("permissao_admin") && (
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight dark:text-gray-400">Administração</h2>
            <div className="space-y-1">
              {adminItems.map((item) => (
                <Button
                  key={item.href}
                  variant={isActive(item.href) ? "secondary" : "ghost"}
                  className={`w-full justify-start ${
                    isActive(item.href)
                      ? "bg-green-100 text-green-900 hover:bg-green-200 hover:text-green-900 dark:bg-green-900/20 dark:text-green-50 dark:hover:bg-green-900/30"
                      : "dark:text-gray-400 dark:hover:text-white"
                  }`}
                  asChild
                  onClick={() => isMobile && setOpen(false)}
                >
                  <Link href={item.href}>
                    {item.icon}
                    <span className="ml-2">{item.title}</span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>
        )}
      </ScrollArea>

      <div className="p-4 border-t dark:border-gray-800">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium dark:text-white">{user?.nome || "Usuário"}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email || ""}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={logout}>
            <LogOut className="h-5 w-5 text-gray-500 dark:text-gray-400" />
          </Button>
        </div>
      </div>
    </div>
  )

  if (isMobile) {
    return (
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="outline" size="icon" className="fixed top-4 left-4 z-40 md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-72 dark:bg-gray-900 dark:border-gray-800">
          {renderNavContent()}
        </SheetContent>
      </Sheet>
    )
  }

  return (
    <div className="hidden md:block w-64 border-r dark:border-gray-800 dark:bg-gray-900 transition-colors">
      {renderNavContent()}
    </div>
  )
}
