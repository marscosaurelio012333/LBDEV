"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/hooks/use-toast"
import { getSupabaseClient } from "@/lib/supabase"
import { useRouter } from "next/navigation"
import { Users, Clock, Calendar, Receipt, DollarSign, ShoppingBag, ArrowRight } from "lucide-react"

interface MesaCardProps {
  mesa: {
    id: string
    numero: string
    capacidade: number
    status: string
    cliente?: string
    horarioAbertura?: string
    tempoOcupacao?: string
    pedidos?: number
    valorTotal?: number
  }
  onStatusChange?: (mesaId: string, novoStatus: string, cliente?: string) => void
  onTransferirMesa?: (mesaOrigemId: string, mesaDestinoNumero: string) => void
}

export function MesaCard({ mesa, onStatusChange, onTransferirMesa }: MesaCardProps) {
  const [ocuparDialogOpen, setOcuparDialogOpen] = useState(false)
  const [transferirDialogOpen, setTransferirDialogOpen] = useState(false)
  const [detalhesDialogOpen, setDetalhesDialogOpen] = useState(false)
  const [finalizarDialogOpen, setFinalizarDialogOpen] = useState(false)
  const [clienteNome, setClienteNome] = useState(mesa.cliente || "")
  const [mesaDestino, setMesaDestino] = useState("")
  const [mesasDisponiveis, setMesasDisponiveis] = useState<{ id: string; numero: string }[]>([])
  const [loading, setLoading] = useState(false)
  const [pedidoItens, setPedidoItens] = useState<any[]>([])
  const { toast } = useToast()
  const router = useRouter()

  // Determinar a cor do status
  let statusColor = ""
  let statusBg = ""

  if (mesa.status === "livre") {
    statusColor = "text-green-600 dark:text-green-400"
    statusBg = "bg-green-100 dark:bg-green-900/20"
  } else if (mesa.status === "ocupada") {
    statusColor = "text-red-600 dark:text-red-400"
    statusBg = "bg-red-100 dark:bg-red-900/20"
  } else if (mesa.status === "em_atendimento") {
    statusColor = "text-yellow-600 dark:text-yellow-400"
    statusBg = "bg-yellow-100 dark:bg-yellow-900/20"
  } else if (mesa.status === "conta_solicitada") {
    statusColor = "text-purple-600 dark:text-purple-400"
    statusBg = "bg-purple-100 dark:bg-purple-900/20"
  } else if (mesa.status === "reservada") {
    statusColor = "text-blue-600 dark:text-blue-400"
    statusBg = "bg-blue-100 dark:bg-blue-900/20"
  } else {
    statusColor = "text-gray-600 dark:text-gray-400"
    statusBg = "bg-gray-100 dark:bg-gray-900/20"
  }

  // Iniciar atendimento - redireciona para o cardápio com a mesa selecionada
  const handleIniciarAtendimento = async () => {
    try {
      // Atualizar status da mesa para "em_atendimento"
      if (onStatusChange) {
        onStatusChange(mesa.id, "em_atendimento")
      }

      // Armazenar ID da mesa no localStorage para recuperar na página do cardápio
      localStorage.setItem("selectedMesaId", mesa.id)
      localStorage.setItem("selectedMesaNumero", mesa.numero)

      // Redirecionar para a página do cardápio
      router.push("/")

      toast({
        title: "Atendimento iniciado",
        description: `Selecione os itens para a Mesa ${mesa.numero}`,
      })
    } catch (error) {
      console.error("Erro ao iniciar atendimento:", error)
      toast({
        title: "Erro",
        description: "Não foi possível iniciar o atendimento",
        variant: "destructive",
      })
    }
  }

  // Enviar pedido para a cozinha
  const handleEnviarParaCozinha = async () => {
    try {
      setLoading(true)
      const supabase = getSupabaseClient()

      // Buscar pedidos da mesa
      const { data: pedidosData, error: pedidosError } = await supabase
        .from("pedidos")
        .select("id")
        .eq("mesa_id", mesa.id)
        .eq("status", "pendente")
        .order("created_at", { ascending: false })
        .limit(1)

      if (pedidosError) throw pedidosError

      if (pedidosData && pedidosData.length > 0) {
        // Atualizar status do pedido para "preparando"
        const { error: updateError } = await supabase
          .from("pedidos")
          .update({ status: "preparando" })
          .eq("id", pedidosData[0].id)

        if (updateError) throw updateError

        toast({
          title: "Pedido enviado",
          description: "O pedido foi enviado para a cozinha",
        })
      } else {
        toast({
          title: "Nenhum pedido encontrado",
          description: "Não há pedidos pendentes para esta mesa",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Erro ao enviar pedido para cozinha:", error)
      toast({
        title: "Erro",
        description: "Não foi possível enviar o pedido para a cozinha",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Solicitar conta
  const handleSolicitarConta = async () => {
    try {
      if (onStatusChange) {
        onStatusChange(mesa.id, "conta_solicitada")
      }

      toast({
        title: "Conta solicitada",
        description: `A conta foi solicitada para a Mesa ${mesa.numero}`,
      })
    } catch (error) {
      console.error("Erro ao solicitar conta:", error)
      toast({
        title: "Erro",
        description: "Não foi possível solicitar a conta",
        variant: "destructive",
      })
    }
  }

  // Buscar mesas disponíveis para transferência
  const handleOpenTransferirDialog = async () => {
    try {
      setLoading(true)
      const supabase = getSupabaseClient()
      const { data, error } = await supabase.from("mesas").select("id, numero").eq("status", "livre").order("numero")

      if (error) throw error

      if (data) {
        setMesasDisponiveis(data)
        setTransferirDialogOpen(true)
      }
    } catch (error) {
      console.error("Erro ao buscar mesas disponíveis:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar as mesas disponíveis",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Buscar detalhes do pedido
  const handleOpenDetalhesDialog = async () => {
    try {
      setLoading(true)
      const supabase = getSupabaseClient()

      // Buscar pedidos da mesa
      const { data: pedidosData, error: pedidosError } = await supabase
        .from("pedidos")
        .select("id")
        .eq("mesa_id", mesa.id)
        .eq("status", "pendente")
        .order("created_at", { ascending: false })
        .limit(1)

      if (pedidosError) throw pedidosError

      if (pedidosData && pedidosData.length > 0) {
        // Buscar itens do pedido
        const { data: itensData, error: itensError } = await supabase
          .from("pedido_itens")
          .select(`
            id,
            quantidade,
            preco_unitario,
            subtotal,
            observacoes,
            status,
            produtos:produto_id (titulo)
          `)
          .eq("pedido_id", pedidosData[0].id)

        if (itensError) throw itensError

        if (itensData) {
          setPedidoItens(itensData)
        }
      }

      setDetalhesDialogOpen(true)
    } catch (error) {
      console.error("Erro ao buscar detalhes do pedido:", error)
      toast({
        title: "Erro",
        description: "Não foi possível carregar os detalhes do pedido",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Finalizar pedido
  const handleFinalizarPedido = async () => {
    try {
      setLoading(true)
      const supabase = getSupabaseClient()

      // Buscar pedidos da mesa
      const { data: pedidosData, error: pedidosError } = await supabase
        .from("pedidos")
        .select("id, total")
        .eq("mesa_id", mesa.id)
        .eq("status", "pendente")
        .order("created_at", { ascending: false })
        .limit(1)

      if (pedidosError) throw pedidosError

      if (pedidosData && pedidosData.length > 0) {
        // Atualizar status do pedido
        const { error: updateError } = await supabase
          .from("pedidos")
          .update({ status: "finalizado" })
          .eq("id", pedidosData[0].id)

        if (updateError) throw updateError

        // Liberar a mesa
        if (onStatusChange) {
          onStatusChange(mesa.id, "livre")
        }

        toast({
          title: "Mesa fechada",
          description: `O pedido da mesa ${mesa.numero} foi finalizado e a mesa foi liberada.`,
        })
      }

      setFinalizarDialogOpen(false)
    } catch (error) {
      console.error("Erro ao finalizar pedido:", error)
      toast({
        title: "Erro",
        description: "Não foi possível finalizar o pedido",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Renderizar ações com base no status da mesa
  const renderActions = () => {
    switch (mesa.status) {
      case "livre":
        return (
          <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => setOcuparDialogOpen(true)}>
            Ocupar Mesa
          </Button>
        )
      case "ocupada":
        return (
          <div className="grid grid-cols-1 gap-2">
            <Button className="w-full bg-yellow-600 hover:bg-yellow-700" onClick={handleIniciarAtendimento}>
              <ShoppingBag className="h-4 w-4 mr-2" />
              Iniciar Atendimento
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300"
                onClick={handleOpenTransferirDialog}
              >
                Transferir
              </Button>
              <Button
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300"
                onClick={() => onStatusChange?.(mesa.id, "livre")}
              >
                Liberar
              </Button>
            </div>
          </div>
        )
      case "em_atendimento":
        return (
          <div className="grid grid-cols-1 gap-2">
            <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={handleEnviarParaCozinha}>
              <ArrowRight className="h-4 w-4 mr-2" />
              Enviar para Cozinha
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300"
                onClick={handleOpenDetalhesDialog}
              >
                Detalhes
              </Button>
              <Button className="bg-purple-600 hover:bg-purple-700" onClick={handleSolicitarConta}>
                <Receipt className="h-4 w-4 mr-2" />
                Solicitar Conta
              </Button>
            </div>
          </div>
        )
      case "conta_solicitada":
        return (
          <div className="grid grid-cols-1 gap-2">
            <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => setFinalizarDialogOpen(true)}>
              <DollarSign className="h-4 w-4 mr-2" />
              Fechar Mesa
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300"
                onClick={handleOpenDetalhesDialog}
              >
                Detalhes
              </Button>
              <Button
                variant="outline"
                className="dark:border-gray-700 dark:text-gray-300"
                onClick={() => onStatusChange?.(mesa.id, "em_atendimento")}
              >
                Voltar
              </Button>
            </div>
          </div>
        )
      case "reservada":
        return (
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              className="dark:border-gray-700 dark:text-gray-300"
              onClick={() => onStatusChange?.(mesa.id, "livre")}
            >
              Cancelar
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={() => onStatusChange?.(mesa.id, "ocupada", mesa.cliente)}
            >
              Ocupar
            </Button>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700 overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl dark:text-white">Mesa {mesa.numero}</CardTitle>
          <Badge className={`${statusBg} ${statusColor} border-0`}>
            {mesa.status === "em_atendimento"
              ? "Em Atendimento"
              : mesa.status === "conta_solicitada"
                ? "Conta Solicitada"
                : mesa.status.charAt(0).toUpperCase() + mesa.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
              <Users className="h-4 w-4" />
              <span>{mesa.capacidade} pessoas</span>
            </div>
            {mesa.status !== "livre" && mesa.horarioAbertura && (
              <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                <Clock className="h-4 w-4" />
                <span>{mesa.horarioAbertura}</span>
              </div>
            )}
            {mesa.status !== "livre" && mesa.cliente && (
              <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                <Users className="h-4 w-4" />
                <span>{mesa.cliente}</span>
              </div>
            )}
            {mesa.status !== "livre" && mesa.tempoOcupacao && (
              <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                <Calendar className="h-4 w-4" />
                <span>{mesa.tempoOcupacao}</span>
              </div>
            )}
          </div>

          {(mesa.status === "em_atendimento" || mesa.status === "conta_solicitada") && (
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-md">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium dark:text-gray-300">Pedido:</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {mesa.pedidos || 0} {mesa.pedidos === 1 ? "item" : "itens"}
                </span>
              </div>
              {mesa.valorTotal && (
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium dark:text-gray-300">Total:</span>
                  <span className="font-bold text-green-600 dark:text-green-400">R${mesa.valorTotal.toFixed(2)}</span>
                </div>
              )}
            </div>
          )}

          {renderActions()}
        </div>
      </CardContent>

      {/* Diálogo para ocupar mesa */}
      <Dialog open={ocuparDialogOpen} onOpenChange={setOcuparDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Ocupar Mesa {mesa.numero}</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Informe o nome do cliente para ocupar esta mesa
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cliente" className="dark:text-gray-300">
                Nome do Cliente
              </Label>
              <Input
                id="cliente"
                value={clienteNome}
                onChange={(e) => setClienteNome(e.target.value)}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setOcuparDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button
              onClick={() => {
                if (onStatusChange) {
                  onStatusChange(mesa.id, "ocupada", clienteNome)
                }
                setOcuparDialogOpen(false)
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              Ocupar Mesa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para transferir mesa */}
      <Dialog open={transferirDialogOpen} onOpenChange={setTransferirDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Transferir Mesa {mesa.numero}</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Selecione a mesa de destino para transferir o cliente
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="mesa-destino" className="dark:text-gray-300">
                Mesa de Destino
              </Label>
              <Select value={mesaDestino} onValueChange={setMesaDestino}>
                <SelectTrigger id="mesa-destino" className="dark:bg-gray-800 dark:border-gray-700 dark:text-white">
                  <SelectValue placeholder="Selecione uma mesa" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-800 dark:border-gray-700">
                  {mesasDisponiveis.map((m) => (
                    <SelectItem key={m.id} value={m.numero}>
                      Mesa {m.numero}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setTransferirDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
            >
              Cancelar
            </Button>
            <Button
              onClick={() => {
                if (mesaDestino && onTransferirMesa) {
                  onTransferirMesa(mesa.id, mesaDestino)
                  setTransferirDialogOpen(false)
                }
              }}
              className="bg-blue-600 hover:bg-blue-700"
              disabled={!mesaDestino}
            >
              Transferir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para detalhes do pedido */}
      <Dialog open={detalhesDialogOpen} onOpenChange={setDetalhesDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Detalhes do Pedido - Mesa {mesa.numero}</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Cliente: {mesa.cliente}</DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-300">Item</TableHead>
                  <TableHead className="dark:text-gray-300">Qtd</TableHead>
                  <TableHead className="text-right dark:text-gray-300">Preço</TableHead>
                  <TableHead className="text-right dark:text-gray-300">Subtotal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pedidoItens.length > 0 ? (
                  pedidoItens.map((item) => (
                    <TableRow key={item.id} className="dark:border-gray-700">
                      <TableCell className="font-medium dark:text-white">{item.produtos?.titulo || "Item"}</TableCell>
                      <TableCell className="dark:text-gray-300">{item.quantidade}</TableCell>
                      <TableCell className="text-right dark:text-gray-300">
                        R${item.preco_unitario.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right dark:text-gray-300">R${item.subtotal.toFixed(2)}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-4 dark:text-gray-400">
                      Nenhum item encontrado
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>

            {mesa.valorTotal && (
              <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-900 rounded-md">
                <div className="flex justify-between items-center">
                  <span className="font-medium dark:text-gray-300">Total:</span>
                  <span className="font-bold text-green-600 dark:text-green-400">R${mesa.valorTotal.toFixed(2)}</span>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button onClick={() => setDetalhesDialogOpen(false)} className="dark:bg-gray-700 dark:text-gray-300">
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Diálogo para finalizar pedido */}
      <Dialog open={finalizarDialogOpen} onOpenChange={setFinalizarDialogOpen}>
        <DialogContent className="sm:max-w-md dark:bg-gray-900 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-white">Fechar Mesa {mesa.numero}</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Confirme para finalizar o pedido e liberar a mesa
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium dark:text-gray-300">Cliente:</span>
                <span className="dark:text-gray-300">{mesa.cliente}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium dark:text-gray-300">Itens:</span>
                <span className="dark:text-gray-300">{mesa.pedidos || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium dark:text-gray-300">Total:</span>
                <span className="font-bold text-green-600 dark:text-green-400">
                  R${mesa.valorTotal ? mesa.valorTotal.toFixed(2) : "0.00"}
                </span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setFinalizarDialogOpen(false)}
              className="dark:border-gray-700 dark:text-gray-300"
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button onClick={handleFinalizarPedido} className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? "Processando..." : "Fechar Mesa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
