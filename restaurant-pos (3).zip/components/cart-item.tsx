"use client"

import { Button } from "@/components/ui/button"
import { Minus, Plus, Trash2 } from "lucide-react"
import { useAppContext } from "@/contexts/app-context"
import type { CartItem as CartItemType } from "@/lib/types"
import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"

interface CartItemProps {
  item: CartItemType
}

export function CartItem({ item }: CartItemProps) {
  const [showObservacoes, setShowObservacoes] = useState(false)
  const [observacoes, setObservacoes] = useState(item.observacoes || "")

  // Usar o contexto com valores padrão
  const appContext = useAppContext()
  const updateCartItemQuantity = appContext?.updateCartItemQuantity || (() => {})
  const removeFromCart = appContext?.removeFromCart || (() => {})
  const updateItemObservacoes = appContext?.updateItemObservacoes || (() => {})

  const handleObservacoesChange = (value: string) => {
    setObservacoes(value)
    if (updateItemObservacoes) {
      updateItemObservacoes(item.id, value)
    }
  }

  return (
    <div className="flex flex-col mb-4 pb-4 border-b dark:border-gray-800">
      <div className="flex items-start">
        <div className="w-16 h-16 rounded-md overflow-hidden mr-3 bg-gray-100 dark:bg-gray-800">
          <img
            src={item.imagem || "/placeholder.svg?height=64&width=64"}
            alt={item.titulo}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <div className="flex justify-between">
            <h3 className="font-medium dark:text-white">{item.titulo}</h3>
            <span className="font-medium dark:text-white">R${(item.preco * item.quantidade).toFixed(2)}</span>
          </div>
          <div className="flex justify-between items-center mt-2">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-6 w-6 rounded-full dark:border-gray-700 dark:text-gray-300"
                onClick={() => updateCartItemQuantity(item.id, item.quantidade - 1)}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <span className="text-sm dark:text-white">{item.quantidade}</span>
              <Button
                variant="outline"
                size="icon"
                className="h-6 w-6 rounded-full dark:border-gray-700 dark:text-gray-300"
                onClick={() => updateCartItemQuantity(item.id, item.quantidade + 1)}
              >
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-400"
              onClick={() => removeFromCart(item.id)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs mt-1 h-6 px-2 text-gray-500 dark:text-gray-400"
            onClick={() => setShowObservacoes(!showObservacoes)}
          >
            {showObservacoes ? "Ocultar observações" : "Adicionar observações"}
          </Button>
          {showObservacoes && (
            <Textarea
              placeholder="Observações (ex: sem cebola, bem passado, etc.)"
              className="mt-2 text-xs min-h-[60px] dark:bg-gray-800 dark:border-gray-700 dark:text-white"
              value={observacoes}
              onChange={(e) => handleObservacoesChange(e.target.value)}
            />
          )}
        </div>
      </div>
    </div>
  )
}
