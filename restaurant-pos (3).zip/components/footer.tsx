"use client"

import { useAppContext } from "@/contexts/app-context"

export function Footer() {
  // Usar o contexto com valores padrão
  const appContext = useAppContext()
  const subtotal = appContext?.subtotal || 0
  const imposto = appContext?.imposto || 0
  const total = appContext?.total || 0

  return (
    <div className="bg-white dark:bg-gray-900 p-4 border-t dark:border-gray-800 transition-colors">
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-500 dark:text-gray-400">© 2025 Chili POS. Todos os direitos reservados.</div>
        <div className="text-sm">
          <span className="mr-4 dark:text-gray-400">
            Subtotal: <span className="font-medium dark:text-white">R${subtotal.toFixed(2)}</span>
          </span>
          <span className="mr-4 dark:text-gray-400">
            Imposto: <span className="font-medium dark:text-white">R${imposto.toFixed(2)}</span>
          </span>
          <span className="dark:text-gray-400">
            Total: <span className="font-medium dark:text-white">R${total.toFixed(2)}</span>
          </span>
        </div>
      </div>
    </div>
  )
}
