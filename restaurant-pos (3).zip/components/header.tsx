"use client"

import type React from "react"
import { Search, Bell } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Header() {
  const [searchTerm, setSearchTerm] = useState("")
  const [notifications, setNotifications] = useState(3)
  // Usar o contexto com valores padrão
  const { isAuthenticated, user } = useAuth()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implementar lógica de pesquisa aqui
    console.log("Pesquisando por:", searchTerm)
  }

  return (
    <div className="bg-white dark:bg-gray-900 p-4 flex items-center gap-4 border-b dark:border-gray-800 transition-colors">
      <form onSubmit={handleSearch} className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <Input
          type="text"
          placeholder="Pesquisar produto..."
          className="pl-10 w-full dark:bg-gray-800 dark:border-gray-700 dark:text-white"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </form>
      <div className="flex items-center gap-2">
        {isAuthenticated && user ? (
          <>
            <span className="font-semibold dark:text-white">{user.cargo || "Usuário"}</span>
            <span className="text-gray-500 dark:text-gray-400 text-sm">{user.nome || "Sem nome"}</span>
          </>
        ) : (
          <span className="text-gray-500 dark:text-gray-400 text-sm">Não autenticado</span>
        )}
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Bell className="h-5 w-5 text-gray-500 dark:text-gray-400 cursor-pointer" />
          {notifications > 0 && (
            <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 bg-red-500">
              {notifications}
            </Badge>
          )}
        </div>
        {isAuthenticated && user && (
          <Avatar className="h-8 w-8">
            <AvatarImage src={user.avatar || ""} alt={user.nome || ""} />
            <AvatarFallback>{user.nome?.charAt(0) || "U"}</AvatarFallback>
          </Avatar>
        )}
      </div>
    </div>
  )
}
