"use client"

import { Card } from "@/components/ui/card"

export function DiningMode() {
  return <Card className="w-full bg-white dark:bg-gray-800 shadow-sm">{/* CardContent removed as requested */}</Card>
}
