"use client"

import { useState, useEffect } from "react"
import { FoodCard } from "@/components/food-card"
import { useAppContext } from "@/contexts/app-context"
import { getSupabaseClient } from "@/lib/supabase"
import { Loader2 } from "lucide-react"

type Product = {
  id: string
  titulo: string
  descricao: string
  preco: number
  imagem: string
  categoria_id: string
  disponivel: boolean
}

export function FoodGrid({ searchQuery = "" }: { searchQuery?: string }) {
  const appContext = useAppContext()
  const selectedCategory = appContext?.selectedCategory || "todos"
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchProducts() {
      try {
        setLoading(true)
        const supabase = getSupabaseClient()

        let query = supabase.from("produtos").select("*").eq("disponivel", true)

        if (selectedCategory !== "todos") {
          query = query.eq("categoria_id", selectedCategory)
        }

        if (searchQuery) {
          query = query.ilike("titulo", `%${searchQuery}%`)
        }

        const { data, error } = await query.order("titulo")

        if (error) {
          console.error("Erro ao buscar produtos:", error)
          setProducts([])
        } else if (data) {
          setProducts(data)
        }
      } catch (error) {
        console.error("Erro ao buscar produtos:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()

    // Configurar atualização em tempo real para produtos
    const supabase = getSupabaseClient()
    const channel = supabase
      .channel("produtos-changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "produtos" }, () => {
        fetchProducts()
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [selectedCategory, searchQuery])

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  if (products.length === 0) {
    return (
      <div className="text-center p-8">
        <p className="text-gray-500">Nenhum produto encontrado</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 py-4">
      {products.map((product) => (
        <FoodCard
          key={product.id}
          id={product.id}
          name={product.titulo}
          description={product.descricao}
          price={product.preco}
          image={product.imagem || "/placeholder.svg?height=200&width=200"}
        />
      ))}
    </div>
  )
}
