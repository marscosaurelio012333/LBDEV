import type { FoodItem } from "./types"

export const foodItems: FoodItem[] = [
  {
    id: "1",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Salada de Vegetais Saudável",
    preco: 17.99,
    desconto: 20,
    tipo: "Vegetariano",
    categoria: "principais",
    quantidade: 0,
  },
  {
    id: "2",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Hambúrguer de Carne com Batatas",
    preco: 23.99,
    tipo: "Não Vegetariano",
    categoria: "sanduiches",
    quantidade: 0,
  },
  {
    id: "3",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Tacos de Salsa com Frango Grelhado",
    preco: 14.99,
    tipo: "Não Vegetariano",
    categoria: "principais",
    quantidade: 0,
  },
  {
    id: "4",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Suco de Laranja Fresco com Sementes de Manjericão",
    preco: 12.99,
    tipo: "Vegetariano",
    categoria: "cafe",
    quantidade: 0,
  },
  {
    id: "5",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Sushi de Carne com Atum",
    preco: 9.99,
    tipo: "Não Vegetariano",
    categoria: "principais",
    quantidade: 0,
  },
  {
    id: "6",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Hambúrguer Vegetariano com Batatas Fritas",
    preco: 10.59,
    desconto: 20,
    tipo: "Vegetariano",
    categoria: "sanduiches",
    quantidade: 0,
  },
  {
    id: "7",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Pizza Margherita",
    preco: 28.99,
    tipo: "Vegetariano",
    categoria: "pizzas",
    quantidade: 0,
  },
  {
    id: "8",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Sopa de Abóbora",
    preco: 8.99,
    tipo: "Vegetariano",
    categoria: "sopas",
    quantidade: 0,
  },
  {
    id: "9",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-12%20at%2012.32.42%20PM-QicgA83ZI0TfZlOynDOqlhOGnbwzEv.jpeg",
    titulo: "Espaguete à Carbonara",
    preco: 19.99,
    tipo: "Não Vegetariano",
    categoria: "massas",
    quantidade: 0,
  },
]

export const pedidos = [
  { mesa: "M1", itens: 6, cozinha: "Cozinha", status: "Em Preparo" },
  { mesa: "M2", itens: 4, cozinha: "Cozinha" },
  { mesa: "M3", itens: 3, cozinha: "Cozinha" },
]
