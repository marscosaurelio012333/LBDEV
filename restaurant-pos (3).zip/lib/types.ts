// Tipos para o sistema de restaurante

// Tipo para modo de refeição
export type ModoRefeicao = "No Local" | "Para Viagem" | "Entrega"

// Tipo para categoria
export interface Categoria {
  icon: any
  label: string
  items: string
  active?: boolean
  id: string
}

// Tipo para item de comida
export type FoodItem = {
  id: string
  image: string
  titulo: string
  descricao?: string
  preco: number
  desconto?: number
  tipo: "Vegetariano" | "Não Vegetariano"
  categoria: string
  quantidade: number
  destaque?: boolean
  disponivel?: boolean
}

// Tipo para item no carrinho
export type CartItem = FoodItem & {
  observacoes?: string
}

// Tipo para pedido
export interface Pedido {
  id: string
  mesa_id?: string
  cliente: string
  modo_refeicao: ModoRefeicao
  metodo_pagamento: string
  subtotal: number
  imposto: number
  total: number
  status: "pendente" | "preparando" | "pronto" | "entregue" | "cancelado"
  criado_em: string
  itens?: PedidoItem[]
  mesa?: Mesa
}

// Tipo para item de pedido
export interface PedidoItem {
  id: string
  pedido_id: string
  produto_id: string
  quantidade: number
  preco_unitario: number
  subtotal: number
  status?: "pendente" | "preparando" | "pronto"
  observacoes?: string
  produto?: FoodItem
}

// Tipo para mesa
export interface Mesa {
  id: string
  numero: string
  capacidade: number
  status: "livre" | "ocupada" | "reservada" | "manutenção"
  cliente?: string
}

// Tipo para usuário
export type User = {
  id: string
  email: string
  nome: string
  permissoes: string[]
}
