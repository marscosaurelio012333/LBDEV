import { createClient } from "@supabase/supabase-js"

// Tipos para o Supabase
export type Usuario = {
  id: string
  nome: string
  email: string
  cargo?: string
  senha_hash?: string
  avatar_url?: string
  permissao_mesas: boolean
  permissao_reservas: boolean
  permissao_entregas: boolean
  permissao_contabilidade: boolean
  permissao_configuracoes: boolean
  permissao_admin: boolean
  permissao_cozinha?: boolean
  ativo: boolean
  criado_em?: string
  ultimo_login?: string
}

// Singleton para o cliente Supabase
let supabaseClient: ReturnType<typeof createClient> | null = null

export function getSupabaseClient() {
  if (!supabaseClient) {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

    supabaseClient = createClient(supabaseUrl, supabaseAnonKey)
  }

  return supabaseClient
}
