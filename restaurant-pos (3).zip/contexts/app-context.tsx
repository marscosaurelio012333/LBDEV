"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type Produto = {
  id: string
  titulo: string
  descricao: string
  preco: number
  categoria_id: string
  imagem: string
  disponivel: boolean
}

type CartItem = {
  id: string
  titulo: string
  preco: number
  quantidade: number
  observacoes?: string
  imagem?: string
}

type AppContextType = {
  cartItems: CartItem[]
  addToCart: (item: Produto, quantidade: number, observacoes?: string) => void
  removeFromCart: (itemId: string) => void
  updateCartItemQuantity: (itemId: string, quantidade: number) => void
  updateCartItemObservacoes: (itemId: string, observacoes: string) => void
  clearCart: () => void
  subtotal: number
  imposto: number
  total: number
  selectedCategory: string | null
  setSelectedCategory: (categoryId: string | null) => void
  modoRefeicao: "No Local" | "Para Viagem" | "Entrega"
  setModoRefeicao: (modo: "No Local" | "Para Viagem" | "Entrega") => void
  selectedTable: string | null
  setSelectedTable: (tableId: string | null) => void
  customerName: string
  setCustomerName: (name: string) => void
  paymentMethod: "dinheiro" | "cartao" | "qrcode" | null
  setPaymentMethod: (method: "dinheiro" | "cartao" | "qrcode" | null) => void
}

const AppContext = createContext<AppContextType | null>(null)

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [modoRefeicao, setModoRefeicao] = useState<"No Local" | "Para Viagem" | "Entrega">("No Local")
  const [selectedTable, setSelectedTable] = useState<string | null>(null)
  const [customerName, setCustomerName] = useState<string>("Cliente")
  const [paymentMethod, setPaymentMethod] = useState<"dinheiro" | "cartao" | "qrcode" | null>(null)

  // Verificar se há uma mesa selecionada no localStorage (para integração com a página de mesas)
  useEffect(() => {
    const storedMesaId = localStorage.getItem("selectedMesaId")
    const storedMesaNumero = localStorage.getItem("selectedMesaNumero")

    if (storedMesaId) {
      setSelectedTable(storedMesaId)
      setModoRefeicao("No Local")

      if (storedMesaNumero) {
        setCustomerName(`Mesa ${storedMesaNumero}`)
      }

      // Limpar após uso
      localStorage.removeItem("selectedMesaId")
      localStorage.removeItem("selectedMesaNumero")
    }
  }, [])

  // Vamos garantir que a quantidade seja sempre um número válido ao adicionar itens ao carrinho

  // Modificar a função addToCart para garantir que quantidade seja sempre um número válido
  const addToCart = (item: Produto, quantidade = 1, observacoes?: string) => {
    // Garantir que quantidade seja um número válido
    const validQuantidade = quantidade > 0 ? quantidade : 1

    setCartItems((prevItems) => {
      // Verificar se o item já existe no carrinho
      const existingItemIndex = prevItems.findIndex((cartItem) => cartItem.id === item.id)

      if (existingItemIndex !== -1) {
        // Se o item já existe, atualizar a quantidade
        const updatedItems = [...prevItems]
        updatedItems[existingItemIndex].quantidade += validQuantidade

        // Se houver novas observações, atualizar
        if (observacoes) {
          updatedItems[existingItemIndex].observacoes = observacoes
        }

        return updatedItems
      } else {
        // Se o item não existe, adicionar ao carrinho
        return [
          ...prevItems,
          {
            id: item.id,
            titulo: item.titulo,
            preco: item.preco,
            quantidade: validQuantidade,
            observacoes,
            imagem: item.imagem,
          },
        ]
      }
    })
  }

  const removeFromCart = (itemId: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId))
  }

  // Modificar a função updateCartItemQuantity para garantir que quantidade seja sempre um número válido
  const updateCartItemQuantity = (itemId: string, quantidade: number) => {
    // Garantir que quantidade seja um número válido
    const validQuantidade = quantidade > 0 ? quantidade : 1

    setCartItems((prevItems) =>
      prevItems.map((item) => (item.id === itemId ? { ...item, quantidade: validQuantidade } : item)),
    )
  }

  const updateCartItemObservacoes = (itemId: string, observacoes: string) => {
    setCartItems((prevItems) => prevItems.map((item) => (item.id === itemId ? { ...item, observacoes } : item)))
  }

  const clearCart = () => {
    setCartItems([])
  }

  // Calcular subtotal, imposto e total
  const subtotal = cartItems.reduce((acc, item) => acc + item.preco * item.quantidade, 0)
  const imposto = subtotal * 0.05 // 5% de imposto
  const total = subtotal + imposto

  return (
    <AppContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateCartItemQuantity,
        updateCartItemObservacoes,
        clearCart,
        subtotal,
        imposto,
        total,
        selectedCategory,
        setSelectedCategory,
        modoRefeicao,
        setModoRefeicao,
        selectedTable,
        setSelectedTable,
        customerName,
        setCustomerName,
        paymentMethod,
        setPaymentMethod,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export const useAppContext = () => useContext(AppContext)
