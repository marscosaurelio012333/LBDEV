"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { getSupabaseClient } from "@/lib/supabase"

// Tipos
export type User = {
  id: string
  nome: string
  email: string
  cargo: string
  avatar?: string
  permissoes: {
    admin: boolean
    mesas: boolean
    reservas: boolean
    entregas: boolean
    contabilidade: boolean
    configuracoes: boolean
    cozinha: boolean
  }
}

type AuthContextType = {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  checkAdmin: () => boolean
  checkPermission: (permission: string) => boolean
}

// Criar um valor padrão para o contexto
const defaultAuthContext: AuthContextType = {
  user: null,
  isLoading: false,
  isAuthenticated: false,
  login: async () => {},
  logout: () => {},
  checkAdmin: () => false,
  checkPermission: () => false,
}

// Test users for development/demo
const TEST_USERS = [
  {
    id: "test-admin",
    nome: "Administrador",
    email: "admin@chilipos.com",
    cargo: "Administrador",
    permissao_mesas: true,
    permissao_reservas: true,
    permissao_entregas: true,
    permissao_contabilidade: true,
    permissao_configuracoes: true,
    permissao_admin: true,
    permissao_cozinha: true,
    ativo: true,
    criado_em: new Date().toISOString(),
    ultimo_login: null,
  },
  {
    id: "test-maria",
    nome: "Maria Silva",
    email: "maria@chilipos.com",
    cargo: "Atendente",
    permissao_mesas: true,
    permissao_reservas: true,
    permissao_entregas: false,
    permissao_contabilidade: false,
    permissao_configuracoes: false,
    permissao_admin: false,
    permissao_cozinha: false,
    ativo: true,
    criado_em: new Date().toISOString(),
    ultimo_login: null,
  },
  {
    id: "test-carlos",
    nome: "Carlos Oliveira",
    email: "carlos@chilipos.com",
    cargo: "Entregador",
    permissao_mesas: false,
    permissao_reservas: false,
    permissao_entregas: true,
    permissao_contabilidade: false,
    permissao_configuracoes: false,
    permissao_admin: false,
    permissao_cozinha: false,
    ativo: true,
    criado_em: new Date().toISOString(),
    ultimo_login: null,
  },
  {
    id: "test-ana",
    nome: "Ana Pereira",
    email: "ana@chilipos.com",
    cargo: "Financeiro",
    permissao_mesas: false,
    permissao_reservas: false,
    permissao_entregas: false,
    permissao_contabilidade: true,
    permissao_configuracoes: false,
    permissao_admin: false,
    permissao_cozinha: false,
    ativo: true,
    criado_em: new Date().toISOString(),
    ultimo_login: null,
  },
  {
    id: "test-joao",
    nome: "João Santos",
    email: "joao@chilipos.com",
    cargo: "Garçom",
    permissao_mesas: true,
    permissao_reservas: false,
    permissao_entregas: false,
    permissao_contabilidade: false,
    permissao_configuracoes: false,
    permissao_admin: false,
    permissao_cozinha: true,
    ativo: true,
    criado_em: new Date().toISOString(),
    ultimo_login: null,
  },
]

// Contexto
const AuthContext = createContext<AuthContextType>(defaultAuthContext)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [useTestUsers, setUseTestUsers] = useState(false) // Flag to use test users instead of database
  const router = useRouter()
  const pathname = usePathname()
  const { toast } = useToast()
  const supabase = getSupabaseClient()

  // Verificar se o usuário está autenticado ao carregar a página
  useEffect(() => {
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser)
        console.log("Usuário recuperado do localStorage:", parsedUser.email)
        setUser(parsedUser)
      } catch (error) {
        console.error("Erro ao analisar usuário armazenado:", error)
        localStorage.removeItem("user")
      }
    } else {
      console.log("Nenhum usuário encontrado no localStorage")
    }

    // Check if we should use test users by default
    const storedUseTestUsers = localStorage.getItem("useTestUsers")
    if (storedUseTestUsers === "true") {
      setUseTestUsers(true)
    }

    setIsLoading(false)
  }, [])

  // Redirecionar usuário não autenticado para login se tentar acessar páginas protegidas
  useEffect(() => {
    if (!isLoading && !user && pathname?.startsWith("/admin")) {
      router.push("/login")
    }
  }, [user, isLoading, pathname, router])

  // Converter usuário do Supabase para o formato do contexto
  const mapUsuarioToUser = (usuario: any): User => {
    return {
      id: usuario.id || "",
      nome: usuario.nome || "",
      email: usuario.email || "",
      cargo: usuario.cargo || "",
      avatar: usuario.avatar_url || "",
      permissoes: {
        admin: usuario.permissao_admin || false,
        mesas: usuario.permissao_mesas || false,
        reservas: usuario.permissao_reservas || false,
        entregas: usuario.permissao_entregas || false,
        contabilidade: usuario.permissao_contabilidade || false,
        configuracoes: usuario.permissao_configuracoes || false,
        cozinha: usuario.permissao_cozinha || false,
      },
    }
  }

  // Function to handle login with test users
  const loginWithTestUser = (email: string, password: string) => {
    const testUser = TEST_USERS.find((user) => user.email === email)

    if (!testUser) {
      throw new Error("Usuário não encontrado ou inativo")
    }

    // In a real system, we would verify the password hash here
    if (password !== "admin123") {
      throw new Error("Senha incorreta")
    }

    // Convert to the format of the user in the context
    const userObj = mapUsuarioToUser(testUser)

    setUser(userObj)
    localStorage.setItem("user", JSON.stringify(userObj))

    // Remember that we're using test users
    localStorage.setItem("useTestUsers", "true")

    toast({
      title: "Login realizado com sucesso",
      description: `Bem-vindo, ${testUser.nome}!`,
    })

    router.push(userObj.permissoes.admin ? "/admin" : "/")
  }

  // Login
  const login = async (email: string, password: string) => {
    setIsLoading(true)

    try {
      // If we've previously encountered database errors, use test users directly
      if (useTestUsers) {
        loginWithTestUser(email, password)
        setIsLoading(false)
        return
      }

      // Try to use the database first
      try {
        // Buscar usuário pelo email
        const { data: usuarios, error } = await supabase.from("usuarios").select("*").eq("email", email).limit(1)

        if (error) {
          console.log("Database error, falling back to test users:", error.message)
          setUseTestUsers(true)
          localStorage.setItem("useTestUsers", "true")
          loginWithTestUser(email, password)
          return
        }

        // If no users found in the database, use test users
        if (!usuarios || usuarios.length === 0) {
          console.log("No users found in database, using test users")
          loginWithTestUser(email, password)
          return
        }

        const usuario = usuarios[0]

        // Check if user is active
        if (!usuario.ativo) {
          throw new Error("Usuário inativo")
        }

        // In a real system, we would verify the password hash here
        // For simplicity, we're comparing directly
        if (password !== "admin123") {
          throw new Error("Senha incorreta")
        }

        try {
          // Atualizar último login
          await supabase.from("usuarios").update({ ultimo_login: new Date().toISOString() }).eq("id", usuario.id)
        } catch (updateError) {
          console.error("Error updating last login:", updateError)
          // Continue with login even if update fails
        }

        // Converter para o formato do usuário no contexto
        const userObj = mapUsuarioToUser(usuario)

        setUser(userObj)
        localStorage.setItem("user", JSON.stringify(userObj))

        toast({
          title: "Login realizado com sucesso",
          description: `Bem-vindo, ${usuario.nome}!`,
        })

        router.push(userObj.permissoes.admin ? "/admin" : "/")
      } catch (dbError) {
        console.error("Database error, falling back to test users:", dbError)
        setUseTestUsers(true)
        localStorage.setItem("useTestUsers", "true")
        loginWithTestUser(email, password)
      }
    } catch (error) {
      console.error("Erro de login:", error)
      toast({
        title: "Erro de autenticação",
        description: error instanceof Error ? error.message : "Email ou senha incorretos",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Logout
  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado com sucesso",
    })
    router.push("/login")
  }

  // Verificar se o usuário é admin
  const checkAdmin = () => {
    return user?.permissoes?.admin === true
  }

  // Verificar permissão específica
  const checkPermission = (permission: string) => {
    if (!user || !user.permissoes) {
      console.log(`Verificação de permissão falhou: ${permission}, usuário não autenticado ou sem permissões`)
      return false
    }

    let hasPermission = false

    switch (permission) {
      case "permissao_admin":
        hasPermission = user.permissoes.admin || false
        break
      case "permissao_mesas":
        hasPermission = user.permissoes.mesas || false
        break
      case "permissao_reservas":
        hasPermission = user.permissoes.reservas || false
        break
      case "permissao_entregas":
        hasPermission = user.permissoes.entregas || false
        break
      case "permissao_contabilidade":
        hasPermission = user.permissoes.contabilidade || false
        break
      case "permissao_configuracoes":
        hasPermission = user.permissoes.configuracoes || false
        break
      case "permissao_cozinha":
        hasPermission = user.permissoes.cozinha || false
        break
      default:
        hasPermission = false
    }

    console.log(`Verificação de permissão: ${permission}, resultado: ${hasPermission}`)
    return hasPermission
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        checkAdmin,
        checkPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  return useContext(AuthContext)
}
